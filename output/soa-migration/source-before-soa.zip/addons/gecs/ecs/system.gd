## System[br]
##
## The base class for all systems within the ECS framework.[br]
##
## Systems contain the core logic and behavior, processing [Entity]s that have specific [Component]s.[br]
## Each system overrides the [method System.query] and returns a query using [code]q[/code] or [code]ECS.world.query[/code][br]
## to define the required [Component]s for it to process [Entity]s and implements the [method System.process] method.[br][br]
## [b]Example (Simple):[/b]
##[codeblock]
##     class_name MovementSystem
##     extends System
##
##     func query():
##         return q.with_all([Transform, Velocity])
##
##     func process(entities: Array[Entity], components: Array, delta: float) -> void:
##         # Per-entity processing (simple but slower)
##         for entity in entities:
##             var transform = entity.get_component(Transform)
##             var velocity = entity.get_component(Velocity)
##             transform.position += velocity.direction * velocity.speed * delta
##[/codeblock]
## [b]Example (Optimized with iterate()):[/b]
##[codeblock]
##     func query():
##         return q.with_all([Transform, Velocity]).iterate([Transform, Velocity])
##
##     func process(entities: Array[Entity], components: Array, delta: float) -> void:
##         # Batch processing with component arrays (faster)
##         var transforms = components[0]
##         var velocities = components[1]
##         for i in entities.size():
##             transforms[i].position += velocities[i].velocity * delta
##[/codeblock]
@icon("res://addons/gecs/assets/system.svg")
class_name System
extends Node

#region Enums
## These control when the system should run in relation to other systems.
enum Runs {
	## This system should run before all the systems defined in the array ex: [TransformSystem] means it will run before the [TransformSystem] system runs
	Before,
	## This system should run after all the systems defined in the array ex: [TransformSystem] means it will run after the [TransformSystem] system runs
	After,
}

## Internal flush mode enum — mirrors @export_enum "PER_SYSTEM","PER_GROUP","MANUAL"
enum FlushMode { PER_SYSTEM, PER_GROUP, MANUAL }

#endregion Enums

#region Exported Variables
## What group this system belongs to. Systems can be organized and run by group
@export var group: String = ""
## Determines whether the system should run even when there are no [Entity]s to process.
@export var process_empty := false
## Is this system active. (Will be skipped if false)
@export var active := true

@export_group("Parallel Processing")
## Enable parallel processing for this system's entities (No access to scene tree in process method)
@export var parallel_processing := false
## Minimum entities required to use parallel processing (performance threshold)
@export var parallel_threshold := 50

@export_group("Command Buffer")
## When to flush the command buffer:
## - PER_SYSTEM: Flush immediately after this system completes (default, safest)
## - PER_GROUP: Flush at the end of the process group (after all systems in the group)
## - MANUAL: Requires manual world.flush_command_buffers() call (for cross-group batching)
@export var command_buffer_flush_mode: FlushMode = FlushMode.PER_SYSTEM

@export_group("Iteration")
## When false (the default since v9), systems iterate the archetype entity arrays
## directly — zero-copy. ALL structural changes made during iteration must go
## through [member cmd] (CommandBuffer); direct add/remove during the loop can
## skip entities via swap-remove (a debug-mode error points offenders at cmd).
## Set to true to restore the v8 behavior: entity arrays are copied before
## iteration so direct structural mutation mid-loop stays safe, at the cost of
## a per-archetype allocation every frame.
## Project-wide escape hatch: set the [code]gecs/settings/safe_iteration_default[/code]
## project setting to true to flip the default back for every system.
@export var safe_iteration: bool = GecsSettings.get_safe_iteration_default()

@export_group("Profiling")
## When true, registers a custom entry named [code]<script_name> - [GECS][/code]
## in Godot's built-in Debugger → Monitors panel, graphing this system's
## current-frame execution time in [b]milliseconds[/b] with decimals — same
## formatting as Godot's built-in [code]Process[/code] / [code]Physics Process[/code]
## monitors. Off by default — enable it per system only for the handful you're
## actively profiling to keep the Monitors list manageable. Toggling at runtime
## registers/unregisters automatically.
@export var performance_monitor: bool = false:
	set = _set_performance_monitor

#endregion Exported Variables

#region Public Variables
## Is this system paused. (Will be skipped if true)
var paused := false
## Optional tick source. If null, system runs every frame (default behavior).
## Multiple systems can share the same [SystemTimer] for synchronized ticking.
## [br]See [method set_tick_rate] for a convenience constructor.
var tick_source: SystemTimer = null

## Logger for system debugging and tracing
var systemLogger = GECSLogger.new().domain("System")
## Data for debugger and profiling - you can add ANY arbitrary data here when ECS.debug is enabled
## All keys and values will automatically appear in the GECS debugger tab
## Example:
##   if ECS.debug:
##       lastRunData["my_counter"] = 123
##       lastRunData["player_stats"] = {"health": 100, "mana": 50}
##       lastRunData["events"] = ["event1", "event2"]
var lastRunData := {}

## Cached display name for the debugger (script basename). Computed once in
## [method _internal_setup] so [method _handle] never rebuilds it per frame.
var _debug_name := ""

## Reference to the world this system belongs to (set by World.add_system)
var _world: World = null
## Convenience property for accessing query builder (returns _world.query or ECS.world.query)
var q: QueryBuilder:
	get:
		return _world.query if _world else (ECS.world.query if ECS.world else null)
## Command buffer for queuing structural changes (add/remove components, entities, relationships)
## Commands are executed after the system completes based on command_buffer_flush_mode
var cmd: CommandBuffer = null:
	get:
		if cmd == null:
			cmd = CommandBuffer.new(_world if _world else ECS.world)
		return cmd

## Cached query to avoid recreating it every frame (lazily initialized)
var _query_cache: QueryBuilder = null
## Cached component keys for iterate() fast path (script instance ids)
var _component_keys: Array = []
## Cached subsystems array (6.0.0 style)
var _subsystems_cache: Array = []
## -1 = unchecked, 0 = no subsystems, 1 = has subsystems (avoids sub_systems() alloc every frame)
var _has_subsystems_cached: int = -1
## Cached non-structural filter result for _query_cache (-1 = uncached, 0 = false, 1 = true)
var _uses_non_structural_cached: int = -1
## Cached non-structural filter result per subsystem index (built once with _subsystems_cache)
var _subsystem_non_structural_cache: Array[int] = []
## Cached per-subsystem timers (null if no timer for that subsystem index)
var _subsystem_timers_cache: Array = []

## CHANGE DETECTION: write-clock baseline from this system's previous run.
## Entities/archetypes whose tracked columns have no writes newer than this
## are skipped when the query uses .changed().
var _last_change_baseline: int = 0
## Per-subsystem baselines (parallel to _subsystems_cache)
var _subsystem_change_baselines: Array[int] = []

## Cached last execution time in ms — mirrored from lastRunData["execution_time_ms"]
## so the Performance monitor callable returns a primitive float with no Dict lookup.
var _last_execution_time_ms: float = 0.0
## Registered Performance custom monitor id, empty when not registered.
var _perf_monitor_id: StringName = &""

## Running min/max/avg execution time, aggregated on the runtime side so the
## numbers stay correct even when the editor debugger drops messages under heavy
## entity churn. Shipped via lastRunData; displayed directly by the GECS tab.
var _metric_min_ms: float = 0.0
var _metric_max_ms: float = 0.0
var _metric_avg_ms: float = 0.0
var _metric_sample_count: int = 0

#endregion Public Variables


#region Public Methods
## Override this method to define the [System]s that this system depends on.[br]
## If not overridden the system will run based on the order of the systems in the [World][br]
## and the order of the systems in the [World] will be based on the order they were added to the [World].[br]
func deps() -> Dictionary[int, Array]:
	return {
		Runs.After: [],
		Runs.Before: [],
	}


## Override this method and return a [QueryBuilder] to define the required [Component]s for the system.[br]
## If not overridden, the system will run on every update with no entities.[br][br]
## You can use [code]q[/code] or [code]ECS.world.query[/code] - both are equivalent.
func query() -> QueryBuilder:
	process_empty = true
	return _world.query if _world else ECS.world.query


## Override this method to define any sub-systems that should be processed by this system.[br]
## Each subsystem is defined as [QueryBuilder, Callable][br]
## Return empty array if not using subsystems (base implementation)[br][br]
## You can use [code]q[/code] or [code]ECS.world.query[/code] in subsystems - both work.[br][br]
## [b]Example:[/b]
## [codeblock]
## func sub_systems() -> Array[Array]:
##     return [
##         [q.with_all([C_Velocity]).iterate([C_Velocity]), process_velocity],
##         [q.with_all([C_Health]), process_health]
##     ]
##
## func process_velocity(entities: Array[Entity], components: Array, delta: float):
##     var velocities = components[0]
##     for i in entities.size():
##         entities[i].position += velocities[i].velocity * delta
##
## func process_health(entities: Array[Entity], components: Array, delta: float):
##     for entity in entities:
##         var health = entity.get_component(C_Health)
##         health.regenerate(delta)
## [/codeblock]
func sub_systems() -> Array[Array]:
	return []  # Base returns empty - overridden systems return populated Array[Array]


## Runs once after the system has been added to the [World] to setup anything on the system one time[br]
func setup():
	pass  # Override in subclasses if needed


## The main processing function for the system.[br]
## Override this method to define your system's behavior.[br]
## [param entities] Array of entities matching the system's query[br]
## [param components] Array of component arrays (in order from iterate()), or empty if no iterate() call[br]
## [param delta] The time elapsed since the last frame[br][br]
## [b]Simple approach:[/b] Loop through entities and use get_component()[br]
## [b]Fast approach:[/b] Use iterate() in query and access component arrays directly
func process(entities: Array[Entity], components: Array, delta: float) -> void:
	pass  # Override in subclasses - base implementation does nothing


## Create and assign an interval [SystemTimer] for this system.[br]
## Returns the timer so it can be shared with other systems.[br][br]
## [b]Example — private timer:[/b]
## [codeblock]
## func setup():
##     set_tick_rate(0.5)  # run every 500ms
## [/codeblock]
## [b]Example — shared timer:[/b]
## [codeblock]
## var timer = system_a.set_tick_rate(0.2)
## system_b.tick_source = timer  # both tick together
## [/codeblock]
func set_tick_rate(interval_seconds: float, single_shot: bool = false) -> SystemTimer:
	var timer = SystemTimer.new()
	timer.interval = interval_seconds
	timer.single_shot = single_shot
	tick_source = timer
	return timer


## Check if this system has a command buffer with pending commands
func has_pending_commands() -> bool:
	return cmd != null and not cmd.is_empty()


## Clear accumulated min/max/avg timing data for this system. Called by the
## GECS debugger tab's Reset Metrics button via a remote debugger message so
## a one-time spike (e.g. first-frame scene load) no longer pollutes the max.
func reset_performance_metrics() -> void:
	_metric_min_ms = 0.0
	_metric_max_ms = 0.0
	_metric_avg_ms = 0.0
	_metric_sample_count = 0


#endregion Public Methods

#region Private Methods


## INTERNAL: Called by World.add_system() to initialize the system
## DO NOT CALL OR OVERRIDE - this is framework code
func _internal_setup():
	# Cache the debugger display name once (script basename) so the per-frame
	# hot path never recomputes it.
	var script := get_script()
	if script and script.resource_path:
		_debug_name = script.resource_path.get_file().get_basename()
	# Call user setup
	setup()
	# If the export flag was ticked in the inspector, register the monitor now that
	# the system is in the tree and the world has given us a resolvable name.
	if performance_monitor and _perf_monitor_id == &"":
		_register_performance_monitor()
	# Editor-only sanity check: warn if the system's query declares observer event
	# modifiers (on_added/on_match/etc.). Those flags have no effect on Systems —
	# the user probably meant to extend Observer. Stripped from release exports via
	# `OS.has_feature("editor")`, which is false in exported builds.
	if OS.has_feature("editor"):
		_warn_if_query_has_observer_events()


func _exit_tree() -> void:
	if _perf_monitor_id != &"":
		_unregister_performance_monitor()


## Setter for [member performance_monitor]. Registers/unregisters the custom
## Performance monitor when the flag flips at runtime (including via the Remote
## inspector during a debug session).
func _set_performance_monitor(value: bool) -> void:
	if value == performance_monitor:
		return
	performance_monitor = value
	# Only (un)register when we're actually in the tree. If the setter fires
	# during scene deserialization before _ready(), _internal_setup() picks it up.
	if not is_inside_tree():
		return
	if value:
		if _perf_monitor_id == &"":
			_register_performance_monitor()
	else:
		if _perf_monitor_id != &"":
			_unregister_performance_monitor()


## Resolve a unique id for this system's Performance monitor. Uses the script
## basename (same shape as [code]lastRunData.system_name[/code]); appends
## [code]#N[/code] if another monitor with that id is already registered so two
## instances of the same system script don't collide.
func _resolve_monitor_name() -> String:
	var base := "unknown"
	var script := get_script()
	if script and script.resource_path:
		base = script.resource_path.get_file().get_basename()
	var candidate := base
	var suffix := 1
	while Performance.has_custom_monitor(&"%s - [GECS]" % candidate):
		suffix += 1
		candidate = "%s#%d" % [base, suffix]
	return candidate


func _register_performance_monitor() -> void:
	var id := &"%s - [GECS]" % _resolve_monitor_name()
	_perf_monitor_id = id
	# MONITOR_TYPE_TIME formats as "X.XX ms" in the Monitors panel, matching the
	# built-in Process / Physics Process monitors. The callable must return the
	# value in [b]seconds[/b]; Godot multiplies internally for the ms display.
	# The MonitorType parameter requires Godot 4.6+, the minimum engine version
	# GECS supports. On 4.5 and earlier this call is a parse error that cascades
	# into "Could not resolve class System" framework-wide (see issue #115).
	(
		Performance
		.add_custom_monitor(
			id,
			Callable(self, "_get_perf_monitor_time"),
			[],
			Performance.MONITOR_TYPE_TIME,
		)
	)


func _unregister_performance_monitor() -> void:
	if Performance.has_custom_monitor(_perf_monitor_id):
		Performance.remove_custom_monitor(_perf_monitor_id)
	_perf_monitor_id = &""


## Callback invoked by Godot's Performance singleton. Must return a primitive
## float and allocate nothing — hot path during Monitors panel sampling.
## Returns the current-frame execution time in [b]seconds[/b]; Godot's
## MONITOR_TYPE_TIME formatter converts it to "X.XX ms" for display.
func _get_perf_monitor_time() -> float:
	return _last_execution_time_ms / 1000.0


func _warn_if_query_has_observer_events() -> void:
	var path: String = get_script().resource_path if get_script() else "<unknown>"
	var main_q: QueryBuilder = query()
	if main_q != null and main_q.has_observer_events():
		push_warning(
			(
				"%s: System.query() declares observer event modifiers (on_added/on_removed/on_changed/on_match/on_unmatch/on_relationship_*/on_event). These have NO effect on Systems — the System still runs every frame. Did you mean to extend Observer instead?"
				% path
			),
		)
	for tuple in sub_systems():
		if tuple.size() >= 1:
			var sq: QueryBuilder = tuple[0] as QueryBuilder
			if sq != null and sq.has_observer_events():
				push_warning(
					(
						"%s: sub_systems() tuple query declares observer event modifiers. These have NO effect on Systems — use sub_observers() on an Observer instead."
						% path
					),
				)


## Process entities in parallel using WorkerThreadPool
## Splits entities into batches and processes them concurrently
func _process_parallel(entities: Array[Entity], components: Array, delta: float) -> void:
	if entities.is_empty():
		return

	# Use OS thread count as fallback since WorkerThreadPool.get_thread_count() doesn't exist
	var worker_count = OS.get_processor_count()
	var batch_size = max(1, entities.size() / worker_count)
	var tasks = []

	# Submit tasks for each batch
	for batch_start in range(0, entities.size(), batch_size):
		var batch_end = min(batch_start + batch_size, entities.size())

		# Slice entities and components for this batch
		var batch_entities = entities.slice(batch_start, batch_end)
		var batch_components = []
		for comp_array in components:
			batch_components.append(comp_array.slice(batch_start, batch_end))

		var task_id = WorkerThreadPool.add_task(
			_process_batch_callable.bind(batch_entities, batch_components, delta)
		)
		tasks.append(task_id)

	# Wait for all tasks to complete
	for task_id in tasks:
		WorkerThreadPool.wait_for_task_completion(task_id)


## Process a batch of entities - called by worker threads
func _process_batch_callable(entities: Array[Entity], components: Array, delta: float) -> void:
	process(entities, components, delta)


## Called by World.process() each frame - main entry point for system execution
## [param delta] The time elapsed since the last frame
func _handle(delta: float) -> void:
	if not active or paused:
		return
	# Timer gate: only run when tick source fires (null = every frame)
	if tick_source and not tick_source.ticked:
		return
	# Always measure time when the Performance monitor is on, even without ECS.debug,
	# so the monitor callable has a live value to return. Explicit bool: Godot 4.6
	# cannot infer types through the ECS autoload reference while this script
	# parses inside the ecs.gd dependency cycle.
	var measure_time: bool = ECS.debug or performance_monitor
	var start_time_usec := 0
	if measure_time:
		start_time_usec = Time.get_ticks_usec()
	if ECS.debug:
		if _debug_name == "":
			var script := get_script()
			if script and script.resource_path:
				_debug_name = script.resource_path.get_file().get_basename()
		lastRunData = {
			"system_name": _debug_name,
			"frame_delta": delta,
		}
	if _has_subsystems_cached == -1:
		_has_subsystems_cached = 1 if not sub_systems().is_empty() else 0
	# CHANGE DETECTION: advance the global write clock once per system run so
	# writes made DURING this run carry a tick newer than this system's baseline
	# (no self-retriggering) while still being seen by later systems.
	Archetype.global_change_tick += 1
	# Track unsafe-iteration depth so the world can flag direct structural
	# mutation during zero-copy iteration (debug aid; safe_iteration systems
	# copy their arrays and are exempt).
	var track_iteration := not safe_iteration and _world != null
	if track_iteration:
		_world._iteration_depth += 1
	if _has_subsystems_cached == 1:
		_run_subsystems(delta)
	else:
		_run_process(delta)
	if track_iteration:
		_world._iteration_depth -= 1
	# Flush command buffer if mode is PER_SYSTEM
	if command_buffer_flush_mode == FlushMode.PER_SYSTEM and has_pending_commands():
		cmd.execute()
	# CHANGE DETECTION: advance the clock again after the run so writes made
	# BETWEEN runs (user code, observers, other frames) stamp a tick strictly
	# newer than this run's baseline — without this they'd tie and be missed.
	Archetype.global_change_tick += 1

	if measure_time:
		var end_time_usec = Time.get_ticks_usec()
		_last_execution_time_ms = (end_time_usec - start_time_usec) / 1000.0
		# Aggregate min/max/avg on the runtime side — every frame contributes even
		# when editor debugger messages are dropped, so peaks are never lost.
		if _metric_sample_count == 0:
			_metric_min_ms = _last_execution_time_ms
			_metric_max_ms = _last_execution_time_ms
		else:
			_metric_min_ms = min(_metric_min_ms, _last_execution_time_ms)
			_metric_max_ms = max(_metric_max_ms, _last_execution_time_ms)
		_metric_sample_count += 1
		_metric_avg_ms = (
			_metric_avg_ms + (_last_execution_time_ms - _metric_avg_ms) / _metric_sample_count
		)
		if ECS.debug:
			lastRunData["execution_time_ms"] = _last_execution_time_ms
			lastRunData["min_ms"] = _metric_min_ms
			lastRunData["max_ms"] = _metric_max_ms
			lastRunData["avg_ms"] = _metric_avg_ms
			lastRunData["sample_count"] = _metric_sample_count


## UNIFIED execution function for both main systems and subsystems
## This ensures consistent behavior and entity processing logic
## Subsystems and main systems execute IDENTICALLY - no special behavior
## [param query_builder] The query to execute
## [param callable] The function to call with matched entities
## [param delta] Time delta
## [param subsystem_index] Index for debug tracking (-1 for main system)
func _run_subsystems(delta: float) -> void:
	if _subsystems_cache.is_empty():
		_subsystems_cache = sub_systems()
		_subsystem_non_structural_cache.clear()
		_subsystem_timers_cache.clear()
		_subsystem_change_baselines.clear()
		for subsystem_tuple in _subsystems_cache:
			var sq := subsystem_tuple[0] as QueryBuilder
			_subsystem_non_structural_cache.append(
				1 if _query_has_non_structural_filters(sq) else 0
			)
			_subsystem_timers_cache.append(
				subsystem_tuple[2] if subsystem_tuple.size() > 2 else null
			)
			_subsystem_change_baselines.append(0)
	var subsystem_index := 0
	for subsystem_tuple in _subsystems_cache:
		var subsystem_query := subsystem_tuple[0] as QueryBuilder
		if subsystem_query._reject_source("System.sub_systems()"):
			subsystem_index += 1
			continue
		var subsystem_callable := subsystem_tuple[1] as Callable
		# Subsystem timer gate: advance and skip if not ticked
		var sub_timer: SystemTimer = _subsystem_timers_cache[subsystem_index]
		if sub_timer:
			sub_timer.advance(delta)
			if not sub_timer.ticked:
				subsystem_index += 1
				continue
		var uses_non_structural := _subsystem_non_structural_cache[subsystem_index] == 1
		var iterate_comps = subsystem_query._iterate_components
		if uses_non_structural:
			# Gather ALL structural entities first then filter once (avoid per-archetype filtering churn)
			var all_entities: Array[Entity] = []
			for arch in subsystem_query.archetypes():
				if not arch.entities.is_empty():
					all_entities.append_array(arch.entities)  # no snapshot to allow mid-frame changes visible to later subsystems
			var filtered = _filter_entities_global(subsystem_query, all_entities)
			if filtered.is_empty():
				if ECS.debug:
					lastRunData[subsystem_index] = {
						"subsystem_index": subsystem_index,
						"entity_count": 0,
						"fallback_execute": true
					}
				subsystem_index += 1
				continue
			var components := []
			if not iterate_comps.is_empty():
				for comp_type in iterate_comps:
					components.append(_build_component_column_from_entities(filtered, comp_type))
			subsystem_callable.call(filtered, components, delta)
			if ECS.debug:
				lastRunData[subsystem_index] = {
					"subsystem_index": subsystem_index,
					"entity_count": filtered.size(),
					"fallback_execute": true
				}
		else:
			# Structural fast path archetype iteration
			var total_entity_count := 0
			var enabled_filter = subsystem_query._enabled_filter
			var changed_keys: Array = subsystem_query.get_changed_keys()
			var has_change_filter := not changed_keys.is_empty()
			var sub_baseline: int = _subsystem_change_baselines[subsystem_index]
			for archetype in subsystem_query.archetypes():
				if archetype.entities.is_empty():
					continue
				if (
					has_change_filter
					and not archetype.has_changes_since(changed_keys, sub_baseline)
				):
					continue
				# Apply enabled/disabled filter at archetype level via bitset
				var arch_entities: Array[Entity]
				if enabled_filter != null:
					arch_entities = archetype.get_entities_by_enabled_state(enabled_filter)
					if has_change_filter:
						arch_entities = _filter_changed_in_baseline(
							archetype, arch_entities, changed_keys, sub_baseline
						)
				elif has_change_filter:
					arch_entities = archetype.get_changed_entities(changed_keys, sub_baseline)
				else:
					# Zero-copy unless safe_iteration opted back in (see _run_process)
					arch_entities = (
						archetype.entities.duplicate() if safe_iteration else archetype.entities
					)
				if arch_entities.is_empty():
					continue
				total_entity_count += arch_entities.size()
				var components = []
				if not iterate_comps.is_empty():
					if enabled_filter != null or has_change_filter:
						# Filtered subset — build columns from entities (can't use archetype columns directly)
						for comp_type in iterate_comps:
							components.append(
								_build_component_column_from_entities(arch_entities, comp_type)
							)
					else:
						for comp_type in iterate_comps:
							var comp_key = (
								comp_type.get_instance_id()
								if comp_type is Script
								else comp_type.get_script().get_instance_id()
							)
							components.append(archetype.get_column(comp_key))
				subsystem_callable.call(arch_entities, components, delta)
			if has_change_filter:
				_subsystem_change_baselines[subsystem_index] = Archetype.global_change_tick
			if ECS.debug:
				lastRunData[subsystem_index] = {
					"subsystem_index": subsystem_index,
					"entity_count": total_entity_count,
					"fallback_execute": false
				}
		subsystem_index += 1


func _run_process(delta: float) -> void:
	if not _query_cache:
		_query_cache = query()
		_uses_non_structural_cached = -1
	if _query_cache._reject_source("System.query()"):
		return
	if _component_keys.is_empty():
		var iterate_comps = _query_cache._iterate_components
		for comp_type in iterate_comps:
			var comp_key = (
				comp_type.get_instance_id()
				if comp_type is Script
				else comp_type.get_script().get_instance_id()
			)
			_component_keys.append(comp_key)
	if _uses_non_structural_cached == -1:
		_uses_non_structural_cached = 1 if _query_has_non_structural_filters(_query_cache) else 0
	var uses_non_structural := _uses_non_structural_cached == 1
	var iterate_comps = _query_cache._iterate_components
	if uses_non_structural:
		# Gather all entities across structural archetypes and then filter once
		var all_entities: Array[Entity] = []
		for arch in _query_cache.archetypes():
			if not arch.entities.is_empty():
				all_entities.append_array(arch.entities)
		if all_entities.is_empty():
			if process_empty:
				process([], [], delta)
			return
		var filtered = _filter_entities_global(_query_cache, all_entities)
		if filtered.is_empty():
			if process_empty:
				process([], [], delta)
			return
		var components := []
		if not iterate_comps.is_empty():
			for comp_type in iterate_comps:
				components.append(_build_component_column_from_entities(filtered, comp_type))
		if parallel_processing and filtered.size() >= parallel_threshold:
			_process_parallel(filtered, components, delta)
		else:
			process(filtered, components, delta)
		if ECS.debug:
			lastRunData["entity_count"] = filtered.size()
			lastRunData["archetype_count"] = _query_cache.archetypes().size()
			lastRunData["fallback_execute"] = true
			lastRunData["parallel"] = parallel_processing and filtered.size() >= parallel_threshold
		return
	# Structural fast path — single pass over archetypes
	var matching_archetypes = _query_cache.archetypes()
	var enabled_filter = _query_cache._enabled_filter
	# CHANGE DETECTION: resolved comp keys when the query uses .changed()
	var changed_keys: Array = _query_cache.get_changed_keys()
	var has_change_filter := not changed_keys.is_empty()
	var processed_any := false
	for arch in matching_archetypes:
		# CHANGE DETECTION: skip the WHOLE archetype when none of the tracked
		# columns wrote since this system's last run — one int compare per column.
		if has_change_filter and not arch.has_changes_since(changed_keys, _last_change_baseline):
			continue
		var arch_entities: Array[Entity]
		if enabled_filter != null:
			arch_entities = arch.get_entities_by_enabled_state(enabled_filter)
			if has_change_filter:
				arch_entities = _filter_changed_in_baseline(
					arch, arch_entities, changed_keys, _last_change_baseline
				)
		elif has_change_filter:
			arch_entities = arch.get_changed_entities(changed_keys, _last_change_baseline)
		else:
			arch_entities = arch.entities
		if arch_entities.is_empty():
			continue
		processed_any = true
		# Snapshot entities to avoid mutation skipping during component add/remove.
		# When safe_iteration is false the system uses CommandBuffer for ALL structural
		# changes so the snapshot copy is unnecessary — use the archetype array directly.
		# When enabled/change filters are set, arch_entities is already a fresh array.
		var snapshot_entities = (
			arch_entities
			if enabled_filter != null or has_change_filter
			else (arch_entities.duplicate() if safe_iteration else arch_entities)
		)
		var components = []
		if not iterate_comps.is_empty():
			if enabled_filter != null or has_change_filter:
				for comp_type in _query_cache._iterate_components:
					components.append(
						_build_component_column_from_entities(snapshot_entities, comp_type)
					)
			else:
				for comp_key in _component_keys:
					components.append(arch.get_column(comp_key))
		if parallel_processing and snapshot_entities.size() >= parallel_threshold:
			if ECS.debug:
				lastRunData["parallel"] = true
				lastRunData["threshold"] = parallel_threshold
			_process_parallel(snapshot_entities, components, delta)
		else:
			if ECS.debug:
				lastRunData["parallel"] = false
			process(snapshot_entities, components, delta)
	# CHANGE DETECTION: writes made during THIS run carry the current tick;
	# adopting it as the new baseline excludes them next frame (no self-retrigger).
	if has_change_filter:
		_last_change_baseline = Archetype.global_change_tick
	if not processed_any:
		if process_empty:
			process([], [], delta)
		if ECS.debug:
			lastRunData["entity_count"] = 0
			lastRunData["archetype_count"] = matching_archetypes.size()
			lastRunData["fallback_execute"] = false
		return
	if ECS.debug:
		var total := 0
		for arch in matching_archetypes:
			total += arch.entities.size()
		lastRunData["entity_count"] = total
		lastRunData["archetype_count"] = matching_archetypes.size()
		lastRunData["fallback_execute"] = false


## Determine if a query includes non-structural filters requiring execute() fallback
func _query_has_non_structural_filters(qb: QueryBuilder) -> bool:
	# Structural relationships (exact type-match, wildcard) are handled at archetype level
	# Only post-filter relationships (property-query, script-target) trigger fallback
	if not qb._post_filter_relationships.is_empty():
		return true
	if not qb._post_filter_ex_relationships.is_empty():
		return true
	if not qb._groups.is_empty():
		return true
	if not qb._exclude_groups.is_empty():
		return true
	# Component property queries (ensure actual queries, not placeholders)
	if not qb._all_components_queries.is_empty():
		for query in qb._all_components_queries:
			if not query.is_empty():
				return true
	if not qb._any_components_queries.is_empty():
		for query in qb._any_components_queries:
			if not query.is_empty():
				return true
	return false


## CHANGE DETECTION: filter an already-selected entity list to rows whose
## tracked columns wrote after [param baseline]. Untracked columns and
## entities outside the archetype count as changed (safe default).
func _filter_changed_in_baseline(
	arch: Archetype, list: Array[Entity], changed_keys: Array, baseline: int
) -> Array[Entity]:
	var out: Array[Entity] = []
	for e in list:
		var index = arch.entity_to_index.get(e, -1)
		for ck in changed_keys:
			var versions = arch.column_versions.get(ck)
			if versions == null or index == -1 or versions[index] > baseline:
				out.append(e)
				break
	return out


## Build component arrays for iterate() when falling back to execute() result (no archetype columns)
func _build_component_column_from_entities(entities: Array[Entity], comp_type) -> Array:
	var out := []
	for e in entities:
		if e == null:
			out.append(null)
			continue
		var comp = e.get_component(comp_type)
		out.append(comp)
	return out


## Filter entities in an archetype for non-structural query criteria (relationships/groups/property queries)
## Filter a flat entity array for non-structural criteria
func _filter_entities_global(qb: QueryBuilder, entities: Array[Entity]) -> Array[Entity]:
	var result: Array[Entity] = []
	for e in entities:
		if e == null:
			continue
		var include := true
		for rel in qb._post_filter_relationships:
			if not e.has_relationship(rel):
				include = false
				break
		if include:
			for ex_rel in qb._post_filter_ex_relationships:
				if e.has_relationship(ex_rel):
					include = false
					break
		if include and not qb._groups.is_empty():
			for g in qb._groups:
				if not e.is_in_group(g):
					include = false
					break
		if include and not qb._exclude_groups.is_empty():
			for g in qb._exclude_groups:
				if e.is_in_group(g):
					include = false
					break
		if include and not qb._all_components_queries.is_empty():
			for i in range(qb._all_components.size()):
				if i >= qb._all_components_queries.size():
					break
				var comp_type = qb._all_components[i]
				var query = qb._all_components_queries[i]
				if not query.is_empty():
					var comp = e.get_component(comp_type)
					if comp == null or not ComponentQueryMatcher.matches_query(comp, query):
						include = false
						break
		if include and not qb._any_components_queries.is_empty():
			var any_match := qb._any_components_queries.is_empty()
			for i in range(qb._any_components.size()):
				if i >= qb._any_components_queries.size():
					break
				var comp_type = qb._any_components[i]
				var query = qb._any_components_queries[i]
				if not query.is_empty():
					var comp = e.get_component(comp_type)
					if comp and ComponentQueryMatcher.matches_query(comp, query):
						any_match = true
						break
			if not any_match and not qb._any_components.is_empty():
				include = false
		if include:
			result.append(e)
	return result


## Debug helper - updates lastRunData (compiled out in production)
func _update_debug_data(callable: Callable = func(): return {}) -> bool:
	if ECS.debug:
		var data = callable.call()
		if data:
			lastRunData.assign(data)
	return true


## Debug helper - sets lastRunData (compiled out in production)
func _debug_data(_lrd: Dictionary, callable: Callable = func(): return {}) -> bool:
	if ECS.debug:
		lastRunData = _lrd
		lastRunData.assign(callable.call())
	return true

#endregion Private Methods

#region Step debugger (used only by GECSStepper; the hot path above is untouched)

## Per-run state for the resumable execution used by [GECSStepper]. Mirrors
## _run_subsystems / _run_process one batch (archetype) at a time so a step
## debugger can stop between process() calls. Not used by the live loop.
var _step_ctx: Dictionary = {}
## Microseconds spent inside user callables during the current stepped run
## (excludes the time the world sat paused between units).
var _step_elapsed_usec: int = 0


## Pre-work of [method _handle]. Returns false when the system would not run
## this frame (inactive, paused or timer-gated).
func _step_begin(delta: float) -> bool:
	if not active or paused:
		return false
	if tick_source and not tick_source.ticked:
		return false
	_step_elapsed_usec = 0
	if ECS.debug:
		if _debug_name == "":
			var script := get_script()
			if script and script.resource_path:
				_debug_name = script.resource_path.get_file().get_basename()
		lastRunData = {
			"system_name": _debug_name,
			"frame_delta": delta,
			"stepped": true,
		}
	if _has_subsystems_cached == -1:
		_has_subsystems_cached = 1 if not sub_systems().is_empty() else 0
	# CHANGE DETECTION: same clock advance as _handle (once per system run).
	Archetype.global_change_tick += 1
	var phases: Array = []
	if _has_subsystems_cached == 1:
		if _subsystems_cache.is_empty():
			_subsystems_cache = sub_systems()
			_subsystem_non_structural_cache.clear()
			_subsystem_timers_cache.clear()
			_subsystem_change_baselines.clear()
			for subsystem_tuple in _subsystems_cache:
				var sq := subsystem_tuple[0] as QueryBuilder
				_subsystem_non_structural_cache.append(
					1 if _query_has_non_structural_filters(sq) else 0
				)
				_subsystem_timers_cache.append(
					subsystem_tuple[2] if subsystem_tuple.size() > 2 else null
				)
				_subsystem_change_baselines.append(0)
		for i in _subsystems_cache.size():
			phases.append(i)
	else:
		if not _query_cache:
			_query_cache = query()
			_uses_non_structural_cached = -1
		if _component_keys.is_empty():
			for comp_type in _query_cache._iterate_components:
				_component_keys.append(
					comp_type.get_instance_id()
					if comp_type is Script
					else comp_type.get_script().get_instance_id()
				)
		if _uses_non_structural_cached == -1:
			_uses_non_structural_cached = (
				1 if _query_has_non_structural_filters(_query_cache) else 0
			)
		phases.append(-1)
	_step_ctx = {
		"phases": phases,
		"phase_i": -1,
		"phase": {},
		"arch_i": 0,
		"processed_any": false,
		"entered": [],
	}
	return true


## Next batch to run: [code]{entities, components, callable, phase, archetype, fallback}[/code],
## or an empty Dictionary when the run is exhausted. Batches are materialized
## lazily, right before they run, so a batch sees every mutation made by the
## batches (and subsystems) before it, exactly like the live loop.
func _step_next_batch(delta: float) -> Dictionary:
	while true:
		var phase: Dictionary = _step_ctx.phase
		if phase.is_empty() or phase.done:
			_step_ctx.phase_i += 1
			if _step_ctx.phase_i >= _step_ctx.phases.size():
				return {}
			phase = _step_enter_phase(_step_ctx.phases[_step_ctx.phase_i], delta)
			_step_ctx.phase = phase
			if phase.skip:
				phase.done = true
				continue
			_step_ctx.entered.append(phase)
			_step_ctx.arch_i = 0
		if phase.non_structural:
			phase.done = true
			var batch := _step_materialize_filtered(phase)
			if batch.is_empty():
				continue
			return batch
		if _step_ctx.arch_i >= phase.archetypes.size():
			phase.done = true
			continue
		var arch: Archetype = phase.archetypes[_step_ctx.arch_i]
		_step_ctx.arch_i += 1
		var batch := _step_materialize_archetype(phase, arch)
		if batch.is_empty():
			continue
		return batch
	return {}


## Enter a phase: a subsystem index, or -1 for the main query. Subsystem timers
## advance here, at phase entry, exactly once per system run (as live does).
func _step_enter_phase(phase_index: int, delta: float) -> Dictionary:
	var phase := {
		"index": phase_index,
		"skip": false,
		"done": false,
		"entity_count": 0,
		"fallback": false,
	}
	if phase_index >= 0:
		var tuple: Array = _subsystems_cache[phase_index]
		var sub_timer: SystemTimer = _subsystem_timers_cache[phase_index]
		if sub_timer:
			sub_timer.advance(delta)
			if not sub_timer.ticked:
				phase.skip = true
				return phase
		phase.query = tuple[0] as QueryBuilder
		phase.callable = tuple[1] as Callable
		phase.non_structural = _subsystem_non_structural_cache[phase_index] == 1
		phase.baseline = _subsystem_change_baselines[phase_index]
	else:
		phase.query = _query_cache
		phase.callable = Callable(self, "process")
		phase.non_structural = _uses_non_structural_cached == 1
		phase.baseline = _last_change_baseline
	var phase_query: QueryBuilder = phase.query
	var context := "System.sub_systems()" if phase_index >= 0 else "System.query()"
	if phase_query._reject_source(context):
		phase.skip = true
		return phase
	phase.iterate_comps = phase_query._iterate_components
	phase.archetypes = phase_query.archetypes()
	phase.enabled_filter = phase_query._enabled_filter
	phase.changed_keys = phase_query.get_changed_keys()
	phase.has_change_filter = not phase.changed_keys.is_empty()
	return phase


## Non-structural fallback: gather every structural match, post-filter once,
## build columns from entities. One batch per phase.
func _step_materialize_filtered(phase: Dictionary) -> Dictionary:
	var all_entities: Array[Entity] = []
	for arch in phase.archetypes:
		if not arch.entities.is_empty():
			all_entities.append_array(arch.entities)
	var filtered: Array[Entity] = _filter_entities_global(phase.query, all_entities)
	phase.entity_count = filtered.size()
	phase.fallback = true
	if filtered.is_empty():
		return {}
	var components := []
	if not phase.iterate_comps.is_empty():
		for comp_type in phase.iterate_comps:
			components.append(_build_component_column_from_entities(filtered, comp_type))
	_step_ctx.processed_any = true
	return {
		"entities": filtered,
		"components": components,
		"callable": phase.callable,
		"phase": phase.index,
		"archetype": null,
		"fallback": true,
	}


## Structural fast path for one archetype: same change / enabled filtering,
## snapshot rule and column sourcing as _run_process / _run_subsystems.
func _step_materialize_archetype(phase: Dictionary, arch: Archetype) -> Dictionary:
	if arch.entities.is_empty():
		return {}
	if phase.has_change_filter and not arch.has_changes_since(phase.changed_keys, phase.baseline):
		return {}
	var arch_entities: Array[Entity]
	if phase.enabled_filter != null:
		arch_entities = arch.get_entities_by_enabled_state(phase.enabled_filter)
		if phase.has_change_filter:
			arch_entities = _filter_changed_in_baseline(
				arch, arch_entities, phase.changed_keys, phase.baseline
			)
	elif phase.has_change_filter:
		arch_entities = arch.get_changed_entities(phase.changed_keys, phase.baseline)
	else:
		arch_entities = arch.entities.duplicate() if safe_iteration else arch.entities
	if arch_entities.is_empty():
		return {}
	phase.entity_count += arch_entities.size()
	var components := []
	if not phase.iterate_comps.is_empty():
		if phase.enabled_filter != null or phase.has_change_filter:
			for comp_type in phase.iterate_comps:
				components.append(_build_component_column_from_entities(arch_entities, comp_type))
		else:
			for comp_type in phase.iterate_comps:
				var comp_key = (
					comp_type.get_instance_id()
					if comp_type is Script
					else comp_type.get_script().get_instance_id()
				)
				components.append(arch.get_column(comp_key))
	_step_ctx.processed_any = true
	return {
		"entities": arch_entities,
		"components": components,
		"callable": phase.callable,
		"phase": phase.index,
		"archetype": arch,
		"fallback": false,
	}


## Run one unit (a whole batch, or a slice of it) through the phase callable.
## Parallel processing is ignored while stepping: units run on the main thread.
func _step_run(entities: Array[Entity], components: Array, callable: Callable, delta: float) -> void:
	var track_iteration := not safe_iteration and _world != null
	var start_usec := Time.get_ticks_usec()
	if track_iteration:
		_world._iteration_depth += 1
	callable.call(entities, components, delta)
	if track_iteration:
		_world._iteration_depth -= 1
	_step_elapsed_usec += Time.get_ticks_usec() - start_usec


## Post-work of [method _handle], in the live order: change baselines, the
## process_empty call, lastRunData, PER_SYSTEM flush, clock advance, timing.
## Stepped runs do not feed the min/max/avg metrics (they would include pauses).
func _step_end(delta: float) -> void:
	var entered: Array = _step_ctx.get("entered", [])
	for phase in entered:
		if phase.has_change_filter:
			if phase.index >= 0:
				_subsystem_change_baselines[phase.index] = Archetype.global_change_tick
			else:
				_last_change_baseline = Archetype.global_change_tick
	if (
		_has_subsystems_cached != 1
		and not _step_ctx.get("processed_any", false)
		and process_empty
		and not _query_cache._has_source
	):
		_step_run([], [], Callable(self, "process"), delta)
	if ECS.debug:
		if _has_subsystems_cached == 1:
			for phase in entered:
				lastRunData[phase.index] = {
					"subsystem_index": phase.index,
					"entity_count": phase.entity_count,
					"fallback_execute": phase.fallback,
				}
		else:
			var main_phase: Dictionary = entered[0] if not entered.is_empty() else {}
			var total := 0
			var arch_count := 0
			if not main_phase.is_empty():
				arch_count = main_phase.archetypes.size()
				if main_phase.fallback:
					total = main_phase.entity_count
				else:
					for arch in main_phase.archetypes:
						total += arch.entities.size()
			lastRunData["entity_count"] = total
			lastRunData["archetype_count"] = arch_count
			lastRunData["fallback_execute"] = main_phase.get("fallback", false)
			lastRunData["parallel"] = false
	if command_buffer_flush_mode == FlushMode.PER_SYSTEM and has_pending_commands():
		cmd.execute()
	Archetype.global_change_tick += 1
	_last_execution_time_ms = _step_elapsed_usec / 1000.0
	if ECS.debug:
		lastRunData["execution_time_ms"] = _last_execution_time_ms
		lastRunData["min_ms"] = _metric_min_ms
		lastRunData["max_ms"] = _metric_max_ms
		lastRunData["avg_ms"] = _metric_avg_ms
		lastRunData["sample_count"] = _metric_sample_count
	_step_ctx = {}

#endregion Step debugger
