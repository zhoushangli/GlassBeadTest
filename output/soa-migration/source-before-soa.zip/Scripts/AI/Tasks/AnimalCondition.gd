@tool
extends BTCondition

@export var condition: StringName

func _generate_name() -> String:
	return "Check " + str(condition)

func _tick(_delta: float) -> Status:
	if not is_instance_valid(agent) or not agent.entity.identity.alive:
		return FAILURE
	var animal := agent.entity as AnimalEntity
	var met := false
	match condition:
		&"has_threat":
			met = animal.sheep_state.threatened or animal.sheep_state.has_panic if animal.sheep_state != null else animal.memory.target != null
		&"is_alert":
			met = animal.sheep_state.has_alert
		&"is_herded":
			met = not animal.sheep_state.dog_pressure.is_zero_approx()
		&"has_nearby_dog":
			met = animal.wolf_state.nearest_threat != null
		&"needs_rest":
			met = animal.wolf_state.resting or (animal.wolf_state.retreating and animal.wolf_state.nearest_threat == null)
		&"has_lost_prey":
			met = animal.wolf_state.hunting and not animal.memory.target_visible
		&"has_prey":
			met = animal.wolf_state.hunting
		&"can_charge":
			met = g_gameplayEngine.wolf_system.can_charge(animal)
		&"must_return":
			met = animal.dog_state.returning
		&"has_stray":
			met = animal.dog_state.collected_sheep != null
	return SUCCESS if met else FAILURE
