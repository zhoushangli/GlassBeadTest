@tool
extends BTAction

var behavior: AnimalEntity.Behavior = AnimalEntity.Behavior.FLOCK

func _generate_name() -> String:
	return AnimalEntity.BEHAVIOR_NAMES[behavior]

func _tick(delta: float) -> Status:
	if not is_instance_valid(agent) or not agent.entity.identity.alive:
		return FAILURE
	agent.entity.brain.current_behavior = behavior
	_execute(delta)
	return RUNNING

func _execute(_delta: float) -> void:
	pass
