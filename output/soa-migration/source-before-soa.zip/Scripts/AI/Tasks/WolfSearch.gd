@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.SEARCH

func _execute(delta: float) -> void:
	var wolf := agent.entity as AnimalEntity
	var memory: AnimalMemory = wolf.memory
	var settings: WolfConfig = wolf.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.move_towards(wolf, memory.last_seen_position, settings.move_speed, delta)
