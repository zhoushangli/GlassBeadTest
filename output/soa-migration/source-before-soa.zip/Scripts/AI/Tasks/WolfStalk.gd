@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.STALK

func _execute(delta: float) -> void:
	var wolf := agent.entity as AnimalEntity
	var motion: AnimalMotion = wolf.motion
	var memory: AnimalMemory = wolf.memory
	var state: WolfState = wolf.wolf_state
	var settings: WolfConfig = wolf.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var point: Vector2 = memory.last_seen_position
	var direction := memory.last_seen_velocity.normalized()
	if direction.is_zero_approx():
		direction = Vector2.RIGHT
	match state.strategy:
		WolfState.Strategy.SIDE:
			point += direction.orthogonal() * settings.strategy_offset
		WolfState.Strategy.REAR:
			point -= direction * settings.strategy_offset
		WolfState.Strategy.HOWL:
			if not state.howled and state.howl_elapsed >= settings.howl_cooldown and motion.position.distance_to(memory.last_seen_position) <= settings.howl_trigger_distance:
				state.howl_pending = true
				state.howled = true
				state.howl_elapsed = 0.0
	common.move_towards(wolf, common.clamp_to_arena(wolf, point), settings.move_speed, delta)
