@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.RETURN

func _execute(delta: float) -> void:
	var dog := agent.entity as AnimalEntity
	var state: SheepdogState = dog.dog_state
	var settings: SheepdogConfig = dog.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.move_towards(dog, state.guard_point, settings.return_speed, delta)
