@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.COLLECT

func _execute(delta: float) -> void:
	var dog := agent.entity as AnimalEntity
	var state: SheepdogState = dog.dog_state
	var settings: SheepdogConfig = dog.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	if common.is_live(dog, state.collected_sheep):
		var away := (state.collected_sheep.motion.position - state.protection_center).normalized()
		var point: Vector2 = common.clamp_to_arena(dog, state.collected_sheep.motion.position + away * settings.collect_distance)
		common.move_towards(dog, point, settings.move_speed, delta)
