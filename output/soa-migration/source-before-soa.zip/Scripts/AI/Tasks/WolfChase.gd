@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.CHASE

func _execute(delta: float) -> void:
	var wolf := agent.entity as AnimalEntity
	var memory: AnimalMemory = wolf.memory
	var state: WolfState = wolf.wolf_state
	var settings: WolfConfig = wolf.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	state.charging = true
	common.move_towards(wolf, memory.last_seen_position, settings.chase_speed, delta)
