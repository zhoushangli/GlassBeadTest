@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.DRIVE

func _execute(delta: float) -> void:
	var dog := agent.entity as AnimalEntity
	var memory: AnimalMemory = dog.memory
	var settings: SheepdogConfig = dog.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.move_towards(dog, memory.last_seen_position, settings.drive_speed, delta)
