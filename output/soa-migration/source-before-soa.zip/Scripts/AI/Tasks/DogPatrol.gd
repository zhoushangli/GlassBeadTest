@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.PATROL

func _execute(delta: float) -> void:
	var dog := agent.entity as AnimalEntity
	var state: SheepdogState = dog.dog_state
	var settings: SheepdogConfig = dog.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	if common.is_live(dog, state.protected_sheep):
		common.move_towards(dog, state.guard_point, settings.move_speed, delta)
	else:
		var point: Vector2 = common.get_wander_point(dog, 85.0)
		common.move_towards(dog, point, settings.move_speed, delta)
