@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.RETREAT

func _execute(delta: float) -> void:
	var wolf := agent.entity as AnimalEntity
	var motion: AnimalMotion = wolf.motion
	var state: WolfState = wolf.wolf_state
	var settings: WolfConfig = wolf.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var wolf_system: WolfSystem = g_gameplayEngine.wolf_system
	wolf_system.end_hunt(wolf, false)
	state.retreating = true
	if common.is_live(wolf, state.nearest_threat):
		var away := (motion.position - state.nearest_threat.motion.position).normalized()
		if away.is_zero_approx():
			away = motion.facing
		common.move_towards(wolf, motion.position + away * 100.0, settings.retreat_speed, delta)
