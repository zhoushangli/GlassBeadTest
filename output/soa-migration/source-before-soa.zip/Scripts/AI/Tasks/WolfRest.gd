@tool
extends "res://Scripts/AI/Tasks/AnimalAction.gd"

func _init() -> void:
	behavior = AnimalEntity.Behavior.REST

func _execute(delta: float) -> void:
	var wolf := agent.entity as AnimalEntity
	var state: WolfState = wolf.wolf_state
	var common: AnimalSystem = g_gameplayEngine.animal_system
	if state.retreating:
		state.retreating = false
		state.resting = true
		state.rest_elapsed = 0.0
	common.submit_velocity(wolf, Vector2.ZERO, 0.0)
