class_name AnimalSystem
extends System

func query() -> QueryBuilder:
	return q.with_all([AnimalIdentity, AnimalMotion]).enabled()

func process(entities: Array[Entity], _components: Array, delta: float) -> void:
	for animal: AnimalEntity in entities:
		move(animal, delta)

func is_live(animal: AnimalEntity, other: AnimalEntity) -> bool:
	return is_instance_valid(other) and other.identity.alive

func can_see(animal: AnimalEntity, point: Vector2) -> bool:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var offset := point - motion.position
	if offset.length_squared() > memory.vision_radius_squared:
		return false
	return offset.is_zero_approx() or motion.facing.dot(offset.normalized()) + 0.000001 >= memory.vision_cos

func observe_target(animal: AnimalEntity, delta: float) -> void:
	var memory: AnimalMemory = animal.memory
	var target := memory.target
	if target == null:
		memory.target_visible = false
		memory.unseen_elapsed = 0.0
		return
	memory.target_visible = can_see(animal, target.motion.position)
	if memory.target_visible:
		memory.last_seen_position = target.motion.position
		memory.last_seen_velocity = target.motion.velocity
		memory.unseen_elapsed = 0.0
	else:
		memory.unseen_elapsed += delta

func perceive(animal: AnimalEntity, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var identity: AnimalIdentity = animal.identity
	motion.wander_remaining -= delta
	memory.perception_remaining -= delta
	if not memory.perception_ready or memory.perception_remaining <= 0.0:
		var service: EntityService = g_gameplayEngine.entity_service
		memory.nearby = service.get_nearby_indices(motion.position, _get_query_radius(animal))
		var started := Time.get_ticks_usec() if g_gameplayEngine.profile_service.detailed_stats_enabled else 0
		_scan_separation(animal, service)
		if g_gameplayEngine.profile_service.detailed_stats_enabled:
			g_gameplayEngine.profile_service.record_hotspot("Separation", started)
			started = Time.get_ticks_usec()
		if identity.kind == AnimalEntity.Kind.SHEEP:
			g_gameplayEngine.sheep_system._scan_neighbors(animal, service)
		if g_gameplayEngine.profile_service.detailed_stats_enabled:
			g_gameplayEngine.profile_service.record_hotspot("NeighborScan", started)
		memory.perception_remaining = g_gameplayEngine.config.perception_interval
		if not memory.perception_ready:
			memory.perception_remaining *= fmod(identity.entity_id * 0.618034, 1.0)
		memory.perception_ready = true

func _get_query_radius(animal: AnimalEntity) -> float:
	var identity: AnimalIdentity = animal.identity
	var settings: Resource = animal.settings
	var radius := maxf(settings.perception_radius, g_gameplayEngine.config.separation_distance)
	if identity.kind == AnimalEntity.Kind.SHEEP:
		radius = maxf(radius, maxf(settings.flock_radius, settings.alignment_radius))
	return radius

func _scan_separation(animal: AnimalEntity, service: EntityService) -> void:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var identity: AnimalIdentity = animal.identity
	motion.separation = Vector2.ZERO
	var distance_limit: float = g_gameplayEngine.config.separation_distance
	if distance_limit <= 0.0:
		return

	for index in memory.nearby:
		if index == memory.perception_index or service.perception_kinds[index] != identity.kind:
			continue

		var offset := motion.position - service.perception_positions[index]
		var distance_squared := offset.length_squared()
		if distance_squared >= distance_limit * distance_limit:
			continue

		var distance := sqrt(distance_squared)
		var direction := offset.normalized()
		if distance < 0.001:
			direction = Vector2.RIGHT if identity.entity_id < service.entities[index].identity.entity_id else Vector2.LEFT
		motion.separation += direction * (1.0 - distance / distance_limit)

func decide(animal: AnimalEntity, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var settings: Resource = animal.settings
	motion.desired_velocity = Vector2.ZERO
	motion.speed_limit = settings.move_speed
	animal.brain.player.update(delta)

func get_wander_point(animal: AnimalEntity, distance: float) -> Vector2:
	var motion: AnimalMotion = animal.motion
	if motion.wander_remaining <= 0.0 or motion.position.distance_to(motion.wander_point) < 15.0:
		var direction := Vector2.from_angle(g_gameplayEngine.rng.randf_range(-PI, PI))
		motion.wander_point = clamp_to_arena(animal, motion.position + direction * distance)
		motion.wander_remaining = g_gameplayEngine.rng.randf_range(1.5, 3.5)
	return motion.wander_point

func clamp_to_arena(animal: AnimalEntity, point: Vector2) -> Vector2:
	return point.clamp(Vector2(12.0, 94.0), g_gameplayEngine.config.arena_size - Vector2(12.0, 58.0))

func move_towards(animal: AnimalEntity, point: Vector2, speed: float, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	motion.movement_goal = point
	motion.speed_limit = speed
	var difference := point - motion.position
	motion.desired_velocity = difference.normalized() * minf(speed, difference.length() / maxf(delta, 0.00001))

func submit_velocity(animal: AnimalEntity, desired: Vector2, speed: float) -> void:
	var motion: AnimalMotion = animal.motion
	motion.desired_velocity = desired
	motion.speed_limit = speed
	motion.movement_goal = motion.position + motion.desired_velocity

func separation_velocity(animal: AnimalEntity) -> Vector2:
	var motion: AnimalMotion = animal.motion
	var identity: AnimalIdentity = animal.identity
	var settings: Resource = animal.settings
	return Vector2.ZERO if identity.kind == AnimalEntity.Kind.SHEEP else motion.separation * settings.move_speed

func move(animal: AnimalEntity, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var identity: AnimalIdentity = animal.identity
	if not identity.alive:
		return

	var previous := motion.position
	motion.velocity = (motion.desired_velocity + separation_velocity(animal)).limit_length(motion.speed_limit)
	motion.position = clamp_to_arena(animal, motion.position + motion.velocity * delta)
	motion.velocity = (motion.position - previous) / maxf(delta, 0.00001)
	if not motion.velocity.is_zero_approx():
		motion.facing = motion.velocity.normalized()

func set_behavior(animal: AnimalEntity, behavior: AnimalEntity.Behavior) -> void:
	animal.brain.current_behavior = behavior
