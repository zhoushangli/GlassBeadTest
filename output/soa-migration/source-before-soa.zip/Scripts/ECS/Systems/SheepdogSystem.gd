class_name SheepdogSystem
extends System

func assign_tasks() -> void:
	var wolves_claimed: Dictionary = {}
	var sheep_claimed: Dictionary = {}
	var assignments: Dictionary = {}
	for dog in g_gameplayEngine.entity_service.dogs:
		if dog.identity.alive:
			assignments[dog] = [null, null]
	# 1) Resolve nearest wolf proposals, then farthest stray proposals.
	for kind in range(2):
		var claimed: Dictionary = wolves_claimed if kind == 0 else sheep_claimed
		var waiting: Array[AnimalEntity] = []
		for dog: AnimalEntity in assignments:
			if assignments[dog][0] == null and not dog.dog_state.returning:
				waiting.append(dog)
		while not waiting.is_empty():
			var proposals: Dictionary = {}
			for dog in waiting:
				var candidates: Array[AnimalEntity] = dog.dog_state.wolf_candidates if kind == 0 else dog.dog_state.stray_candidates
				var best: AnimalEntity
				var best_score: float = INF
				for animal in candidates:
					if claimed.has(animal):
						continue
					var score := dog.motion.position.distance_squared_to(task_point(dog, animal)) if kind == 0 else -dog.dog_state.protection_center.distance_squared_to(animal.motion.position)
					if score < best_score or (is_equal_approx(score, best_score) and best != null and animal.identity.entity_id < best.identity.entity_id):
						best = animal
						best_score = score
				if best == null:
					continue
				var previous: AnimalEntity = proposals.get(best)
				var distance := dog.motion.position.distance_squared_to(task_point(dog, best))
				var previous_distance := previous.motion.position.distance_squared_to(task_point(previous, best)) if previous != null else INF
				if distance < previous_distance or (is_equal_approx(distance, previous_distance) and previous != null and dog.identity.entity_id < previous.identity.entity_id):
					proposals[best] = dog
			if proposals.is_empty():
				break
			for animal: AnimalEntity in proposals:
				var dog: AnimalEntity = proposals[animal]
				assignments[dog][kind] = animal
				claimed[animal] = dog
				waiting.erase(dog)
	for dog: AnimalEntity in assignments:
		apply_assignment(dog, assignments[dog][0], assignments[dog][1])

func query() -> QueryBuilder:
	return q.with_all([SheepdogState]).enabled()

func process(entities: Array[Entity], _components: Array, delta: float) -> void:
	for animal: AnimalEntity in entities:
		perceive(animal, delta)

func perceive(animal: AnimalEntity, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var identity: AnimalIdentity = animal.identity
	var state: SheepdogState = animal.dog_state
	var settings: SheepdogConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.perceive(animal, delta)
	state.assignment_remaining -= delta
	if not common.is_live(animal, state.protected_sheep) or state.assignment_remaining <= 0.0:
		_choose_protection_anchor(animal)
		state.assignment_remaining = settings.reassignment_interval
	_update_protection_center(animal)
	state.patrol_angle += settings.patrol_angular_speed * delta * (1.0 if identity.entity_id % 2 == 0 else -1.0)
	state.guard_point = common.clamp_to_arena(animal, state.protection_center + Vector2.from_angle(state.patrol_angle) * settings.guard_distance)
	common.observe_target(animal, delta)
	if not common.is_live(animal, state.protected_sheep):
		memory.target = null
		state.returning = false
	elif motion.position.distance_to(state.protection_center) > settings.leash_distance:
		state.returning = true
	if state.returning and motion.position.distance_to(state.guard_point) <= 24.0:
		state.returning = false
	state.wolf_candidates.clear()
	state.stray_candidates.clear()
	var anchor := state.protected_sheep
	if state.returning or not common.is_live(animal, anchor):
		return
	var service: EntityService = g_gameplayEngine.entity_service
	var flock: Array[Vector2] = []
	for index in service.get_nearby_indices(anchor.motion.position, settings.local_flock_radius):
		if service.perception_kinds[index] == AnimalEntity.Kind.SHEEP and anchor.motion.position.distance_to(service.perception_positions[index]) <= settings.local_flock_radius:
			flock.append(service.perception_positions[index])
	for wolf in service.wolves:
		if not wolf.identity.alive or not common.can_see(animal, wolf.motion.position):
			continue
		var threatening: bool = wolf.wolf_state.hunting
		for point in flock:
			if wolf.motion.position.distance_to(point) < settings.threat_distance:
				threatening = true
				break
		if threatening:
			state.wolf_candidates.append(wolf)
	if common.is_live(animal, memory.target) and not memory.target_visible and memory.unseen_elapsed < settings.memory_duration:
		state.wolf_candidates.append(memory.target)
	var radius: float = settings.local_flock_radius
	for index in service.get_nearby_indices(anchor.motion.position, radius * 2.0):
		if service.perception_kinds[index] != AnimalEntity.Kind.SHEEP:
			continue
		var sheep := service.entities[index] as AnimalEntity
		var point := service.perception_positions[index]
		var distance := state.protection_center.distance_to(point)
		var threshold: float = radius * settings.collect_complete_ratio if sheep == state.collected_sheep else radius
		if anchor.motion.position.distance_to(point) <= radius * 2.0 and distance > threshold:
			state.stray_candidates.append(sheep)

func task_point(animal: AnimalEntity, other: AnimalEntity) -> Vector2:
	var memory: AnimalMemory = animal.memory
	if other == memory.target and not memory.target_visible:
		return memory.last_seen_position
	return other.motion.position

func apply_assignment(animal: AnimalEntity, wolf: AnimalEntity, stray: AnimalEntity) -> void:
	var memory: AnimalMemory = animal.memory
	var state: SheepdogState = animal.dog_state
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var lost_wolf: bool = common.is_live(animal, memory.target) and wolf == null
	if wolf != memory.target:
		memory.target = wolf
		common.observe_target(animal, 0.0)
	state.collected_sheep = stray as AnimalEntity
	if lost_wolf:
		state.returning = true

func _anchor_score(animal: AnimalEntity, sheep: AnimalEntity, anchors: PackedVector2Array) -> float:
	var motion: AnimalMotion = animal.motion
	var settings: SheepdogConfig = animal.settings
	var point := sheep.motion.position
	var coverage: int = 0
	for anchor in anchors:
		if anchor.distance_to(point) < settings.local_flock_radius:
			coverage += 1
	return motion.position.distance_to(point) / settings.local_flock_radius + coverage * settings.coverage_weight

func _choose_protection_anchor(animal: AnimalEntity) -> void:
	var state: SheepdogState = animal.dog_state
	var settings: SheepdogConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var started := Time.get_ticks_usec() if g_gameplayEngine.profile_service.detailed_stats_enabled else 0
	var anchors := PackedVector2Array()
	for dog in g_gameplayEngine.entity_service.dogs:
		var anchor: AnimalEntity = dog.dog_state.protected_sheep
		if dog != animal and dog.identity.alive and anchor != null:
			anchors.append(anchor.motion.position)
	var best: AnimalEntity = state.protected_sheep if common.is_live(animal, state.protected_sheep) else null
	var current_score: float = _anchor_score(animal, best, anchors) if best != null else INF
	var best_score := current_score
	for sheep in g_gameplayEngine.entity_service.sheep:
		if not sheep.identity.alive:
			continue
		var score: float = _anchor_score(animal, sheep, anchors)
		if score < best_score:
			best = sheep
			best_score = score

	if not common.is_live(animal, state.protected_sheep) or best_score <= current_score * (1.0 - settings.reassignment_improvement):
		state.protected_sheep = best
	if g_gameplayEngine.profile_service.detailed_stats_enabled:
		g_gameplayEngine.profile_service.record_hotspot("DogAnchor", started)

func _update_protection_center(animal: AnimalEntity) -> void:
	var state: SheepdogState = animal.dog_state
	var anchor := state.protected_sheep
	var settings: SheepdogConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	if not common.is_live(animal, anchor):
		state.protection_center = common.get_wander_point(animal, 85.0)
		return

	var center := Vector2.ZERO
	var count: int = 0
	var service: EntityService = g_gameplayEngine.entity_service
	for index in service.get_nearby_indices(anchor.motion.position, settings.local_flock_radius):
		if service.perception_kinds[index] == AnimalEntity.Kind.SHEEP:
			var point := service.perception_positions[index]
			if point.distance_to(anchor.motion.position) <= settings.local_flock_radius:
				center += point
				count += 1
	state.protection_center = center / count if count > 0 else anchor.motion.position

func get_debug_details(animal: AnimalEntity) -> String:
	var memory: AnimalMemory = animal.memory
	var state: SheepdogState = animal.dog_state
	var common: AnimalSystem = g_gameplayEngine.animal_system
	return "Anchor #%d | Stray #%d | Unseen %.1f s" % [state.protected_sheep.identity.entity_id if common.is_live(animal, state.protected_sheep) else 0, state.collected_sheep.identity.entity_id if common.is_live(animal, state.collected_sheep) else 0, memory.unseen_elapsed]
