class_name AnimalStageSystem
extends System

enum Stage { DECISION, INTERACTION, PRESENTATION }

var stage: Stage = Stage.DECISION

func query() -> QueryBuilder:
	if stage == Stage.INTERACTION:
		return q.with_all([WolfState]).enabled()
	return q.with_all([AnimalIdentity, AnimalBrain]).enabled()

func process(entities: Array[Entity], _components: Array, delta: float) -> void:
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var wolves: WolfSystem = g_gameplayEngine.wolf_system
	for animal: AnimalEntity in entities:
		if not animal.identity.alive:
			continue
		match stage:
			Stage.DECISION:
				common.decide(animal, delta)
			Stage.INTERACTION:
				wolves.resolve_interactions(animal, delta)
			Stage.PRESENTATION:
				animal.brain.view.sync()
