class_name SheepSystem
extends System

func query() -> QueryBuilder:
	return q.with_all([SheepState]).enabled()

func process(entities: Array[Entity], _components: Array, delta: float) -> void:
	for animal: AnimalEntity in entities:
		perceive(animal, delta)

func _scan_neighbors(animal: AnimalEntity, service: EntityService) -> void:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var state: SheepState = animal.sheep_state
	var settings: SheepConfig = animal.settings
	state.local_flock_center = Vector2.ZERO
	state.alignment = Vector2.ZERO
	state.neighbor_count = 0
	var aligned: int = 0
	for index in memory.nearby:
		if index == memory.perception_index or service.perception_kinds[index] != AnimalEntity.Kind.SHEEP:
			continue
		var distance := motion.position.distance_to(service.perception_positions[index])
		if distance < settings.flock_radius:
			state.local_flock_center += service.perception_positions[index]
			state.neighbor_count += 1
		if distance < settings.alignment_radius:
			state.alignment += service.perception_velocities[index]
			aligned += 1
	state.local_flock_center = state.local_flock_center / state.neighbor_count if state.neighbor_count > 0 else motion.position
	if aligned > 0:
		state.alignment /= aligned

func receive_howl(animal: AnimalEntity, source: Vector2) -> void:
	var state: SheepState = animal.sheep_state
	state.panic_source = source
	state.panic_elapsed = 0.0
	state.has_panic = true
	state.has_alert = true
	state.alert_elapsed = 0.0

func perceive(animal: AnimalEntity, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var identity: AnimalIdentity = animal.identity
	var state: SheepState = animal.sheep_state
	var settings: SheepConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.perceive(animal, delta)
	state.threatened = false
	state.threat_direction = Vector2.ZERO
	state.dog_pressure = Vector2.ZERO
	var service: EntityService = g_gameplayEngine.entity_service
	for index in service.get_nearby_indices(motion.position, maxf(settings.perception_radius, settings.herding_distance)):
		var kind: int = service.perception_kinds[index]
		if kind != AnimalEntity.Kind.WOLF and kind != AnimalEntity.Kind.SHEEPDOG:
			continue
		var point := service.perception_positions[index]
		var offset := motion.position - point
		var distance := offset.length()
		match kind:
			AnimalEntity.Kind.WOLF:
				if distance <= settings.emergency_distance or common.can_see(animal, point):
					state.threatened = true
					state.threat_direction += offset.normalized() / maxf(distance, 1.0)
			AnimalEntity.Kind.SHEEPDOG:
				if distance < settings.herding_distance:
					state.dog_pressure += offset.normalized() * (1.0 - distance / settings.herding_distance)
	if state.has_panic:
		state.panic_elapsed += delta
		state.has_panic = state.panic_elapsed < settings.panic_duration
		if state.has_panic:
			state.threat_direction += (motion.position - state.panic_source).normalized()
	if state.threatened or state.has_panic:
		state.has_alert = true
		state.alert_elapsed = 0.0
	else:
		state.alert_elapsed += delta
		state.has_alert = state.has_alert and state.alert_elapsed < settings.alert_duration
	if (state.threatened or state.has_panic) and state.threat_direction.is_zero_approx():
		state.threat_direction = Vector2.from_angle(identity.entity_id * 2.399963)

func get_flock_velocity(animal: AnimalEntity) -> Vector2:
	var motion: AnimalMotion = animal.motion
	var state: SheepState = animal.sheep_state
	var settings: SheepConfig = animal.settings
	var cohesion := (state.local_flock_center - motion.position).normalized() if state.neighbor_count > 0 else Vector2.ZERO
	return state.alignment * settings.alignment_weight + cohesion * settings.move_speed * settings.cohesion_weight

func apply_steering(animal: AnimalEntity, steering: Vector2, flock: Vector2, speed: float, delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var settings: SheepConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	steering += flock + motion.separation * settings.move_speed * settings.separation_weight
	var margin: float = 40.0
	var lower := Vector2(12.0, 94.0) + Vector2.ONE * margin
	var upper: Vector2 = g_gameplayEngine.config.arena_size - Vector2(12.0, 58.0) - Vector2.ONE * margin
	var boundary := (lower - motion.position).max(Vector2.ZERO) - (motion.position - upper).max(Vector2.ZERO)
	steering += boundary / margin * speed * 2.0
	var desired := motion.velocity.lerp(steering.limit_length(speed), minf(1.0, settings.steering_rate * delta))
	common.submit_velocity(animal, desired, speed)

func get_debug_details(animal: AnimalEntity) -> String:
	var state: SheepState = animal.sheep_state
	var settings: SheepConfig = animal.settings
	return "Neighbors %d | Alert %.1f s | Panic %.1f s" % [state.neighbor_count, maxf(0.0, settings.alert_duration - state.alert_elapsed) if state.has_alert else 0.0, maxf(0.0, settings.panic_duration - state.panic_elapsed) if state.has_panic else 0.0]
