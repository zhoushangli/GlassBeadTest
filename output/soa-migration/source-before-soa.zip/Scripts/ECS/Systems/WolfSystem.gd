class_name WolfSystem
extends System

func query() -> QueryBuilder:
	return q.with_all([WolfState]).enabled()

func process(entities: Array[Entity], _components: Array, delta: float) -> void:
	for animal: AnimalEntity in entities:
		perceive(animal, delta)

func find_dog(animal: AnimalEntity, radius: float) -> AnimalEntity:
	var motion: AnimalMotion = animal.motion
	var result: AnimalEntity
	var best := radius
	for dog in g_gameplayEngine.entity_service.dogs:
		if not dog.identity.alive:
			continue
		var distance := motion.position.distance_to(dog.motion.position)
		if distance < best or (is_equal_approx(distance, best) and result != null and dog.identity.entity_id < result.identity.entity_id):
			result = dog
			best = distance
	return result

func perceive(animal: AnimalEntity, delta: float) -> void:
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	var settings: WolfConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	common.perceive(animal, delta)
	for index in range(state.strategy_failures.size()):
		state.strategy_failures[index] = maxf(0.0, state.strategy_failures[index] - settings.strategy_decay * delta)
	state.howl_elapsed += delta
	if state.resting:
		state.rest_elapsed += delta
		state.resting = state.rest_elapsed < settings.rest_duration
	state.nearest_threat = find_dog(animal, settings.dog_threat_distance * (2.0 if state.retreating else 1.0))
	if state.hunting:
		state.hunt_elapsed += delta
		common.observe_target(animal, delta)
		if not common.is_live(animal, memory.target) or state.hunt_elapsed >= settings.hunt_duration or (not memory.target_visible and memory.unseen_elapsed >= settings.memory_duration):
			end_hunt(animal, false)
	if not state.hunting and not state.resting and not common.is_live(animal, state.nearest_threat) and not state.retreating:
		_choose_prey(animal)

func _choose_prey(animal: AnimalEntity) -> void:
	var motion: AnimalMotion = animal.motion
	var settings: WolfConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	var started := Time.get_ticks_usec() if g_gameplayEngine.profile_service.detailed_stats_enabled else 0
	var best: AnimalEntity
	var distance: float = INF
	var service: EntityService = g_gameplayEngine.entity_service
	for index in service.get_nearby_indices(motion.position, settings.perception_radius):
		if service.perception_kinds[index] != AnimalEntity.Kind.SHEEP:
			continue
		var point := service.perception_positions[index]
		if not common.can_see(animal, point):
			continue
		var candidate := service.entities[index] as AnimalEntity
		var next_distance := motion.position.distance_squared_to(point)
		if next_distance < distance or (is_equal_approx(next_distance, distance) and best != null and candidate.identity.entity_id < best.identity.entity_id):
			best = candidate
			distance = next_distance
	if best != null:
		begin_hunt(animal, best)
	if g_gameplayEngine.profile_service.detailed_stats_enabled:
		g_gameplayEngine.profile_service.record_hotspot("WolfTarget", started)

func begin_hunt(animal: AnimalEntity, prey: AnimalEntity) -> void:
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	var common: AnimalSystem = g_gameplayEngine.animal_system
	memory.target = prey
	state.hunting = true
	state.hunt_elapsed = 0.0
	state.charging = false
	state.howled = false
	var total: float = 0.0
	for failures in state.strategy_failures:
		total += 1.0 / (1.0 + failures)
	var choice: float = g_gameplayEngine.rng.randf() * total
	for index in range(state.strategy_failures.size()):
		choice -= 1.0 / (1.0 + state.strategy_failures[index])
		if choice <= 0.0 or index == state.strategy_failures.size() - 1:
			state.strategy = index as WolfState.Strategy
			break
	common.observe_target(animal, 0.0)

func end_hunt(animal: AnimalEntity, success: bool) -> void:
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	if not state.hunting:
		return
	state.strategy_failures[state.strategy] = maxf(0.0, state.strategy_failures[state.strategy] + (-1.5 if success else 1.0))
	state.hunting = false
	state.charging = false
	memory.target = null
	memory.target_visible = false
	state.resting = true
	state.rest_elapsed = 0.0

func can_charge(animal: AnimalEntity) -> bool:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	var settings: WolfConfig = animal.settings
	return state.hunting and memory.target_visible and (state.charging or motion.position.distance_to(memory.last_seen_position) <= settings.capture_distance * settings.charge_distance_scale)

func resolve_interactions(animal: AnimalEntity, _delta: float) -> void:
	var motion: AnimalMotion = animal.motion
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	var settings: WolfConfig = animal.settings
	var common: AnimalSystem = g_gameplayEngine.animal_system
	if state.howl_pending:
		state.howl_pending = false
		g_gameplayEngine.debug_service.record_howl(animal)
		for sheep in g_gameplayEngine.entity_service.sheep:
			if sheep.identity.alive and motion.position.distance_to(sheep.motion.position) <= settings.howl_radius:
				g_gameplayEngine.sheep_system.receive_howl(sheep, motion.position)
	if not state.hunting or animal.brain.current_behavior != AnimalEntity.Behavior.CHASE:
		return
	if not common.is_live(animal, memory.target):
		end_hunt(animal, false)
		return
	state.nearest_threat = find_dog(animal, settings.dog_threat_distance)
	if common.is_live(animal, state.nearest_threat):
		end_hunt(animal, false)
		state.retreating = true
		return
	if common.can_see(animal, memory.target.motion.position) and motion.position.distance_to(memory.target.motion.position) <= settings.capture_distance:
		if g_gameplayEngine.entity_service.capture(memory.target):
			end_hunt(animal, true)

func get_debug_details(animal: AnimalEntity) -> String:
	var memory: AnimalMemory = animal.memory
	var state: WolfState = animal.wolf_state
	return "%s | Hunt %.1f s | Unseen %.1f s | Failures %s" % [WolfState.STRATEGY_NAMES[state.strategy], state.hunt_elapsed, memory.unseen_elapsed, state.strategy_failures]
