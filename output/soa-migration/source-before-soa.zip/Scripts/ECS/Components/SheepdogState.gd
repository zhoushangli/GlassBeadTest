class_name SheepdogState
extends Component

var protection_center := Vector2.ZERO
var guard_point := Vector2.ZERO
var wolf_candidates: Array[AnimalEntity] = []
var stray_candidates: Array[AnimalEntity] = []
var assignment_remaining: float = 0.0
var returning: bool = false
var patrol_angle: float = 0.0
var _protected_sheep: AnimalEntity
var _protected_sheep_generation: int = 0
var protected_sheep: AnimalEntity:
	get:
		if is_instance_valid(_protected_sheep) and _protected_sheep.identity.generation == _protected_sheep_generation and _protected_sheep.identity.alive:
			return _protected_sheep
		return null
	set(value):
		_protected_sheep = value
		_protected_sheep_generation = value.identity.generation if is_instance_valid(value) else 0
var _collected_sheep: AnimalEntity
var _collected_sheep_generation: int = 0
var collected_sheep: AnimalEntity:
	get:
		if is_instance_valid(_collected_sheep) and _collected_sheep.identity.generation == _collected_sheep_generation and _collected_sheep.identity.alive:
			return _collected_sheep
		return null
	set(value):
		_collected_sheep = value
		_collected_sheep_generation = value.identity.generation if is_instance_valid(value) else 0

func reset() -> void:
	protected_sheep = null
	collected_sheep = null
	protection_center = Vector2.ZERO
	guard_point = Vector2.ZERO
	wolf_candidates = []
	stray_candidates = []
	assignment_remaining = 0.0
	returning = false
	patrol_angle = 0.0
