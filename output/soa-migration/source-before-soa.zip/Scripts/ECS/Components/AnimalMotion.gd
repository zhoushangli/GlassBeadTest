class_name AnimalMotion
extends Component

var position := Vector2.ZERO
var facing := Vector2.RIGHT
var velocity := Vector2.ZERO
var desired_velocity := Vector2.ZERO
var movement_goal := Vector2.ZERO
var separation := Vector2.ZERO
var speed_limit: float = 0.0
var wander_point := Vector2.ZERO
var wander_remaining: float = 0.0

func reset() -> void:
	position = Vector2.ZERO
	facing = Vector2.RIGHT
	velocity = Vector2.ZERO
	desired_velocity = Vector2.ZERO
	movement_goal = Vector2.ZERO
	separation = Vector2.ZERO
	speed_limit = 0.0
	wander_point = Vector2.ZERO
	wander_remaining = 0.0
