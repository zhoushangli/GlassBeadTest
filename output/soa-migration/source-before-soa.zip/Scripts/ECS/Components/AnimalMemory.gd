class_name AnimalMemory
extends Component

var last_seen_position := Vector2.ZERO
var last_seen_velocity := Vector2.ZERO
var unseen_elapsed: float = 0.0
var target_visible: bool = false
var perception_index: int = -1
var nearby: Array[int] = []
var perception_remaining: float = 0.0
var perception_ready: bool = false
var vision_radius_squared: float = 0.0
var vision_cos: float = -1.0
var _target: AnimalEntity
var _target_generation: int = 0
var target: AnimalEntity:
	get:
		if is_instance_valid(_target) and _target.identity.generation == _target_generation and _target.identity.alive:
			return _target
		return null
	set(value):
		_target = value
		_target_generation = value.identity.generation if is_instance_valid(value) else 0

func reset() -> void:
	target = null
	last_seen_position = Vector2.ZERO
	last_seen_velocity = Vector2.ZERO
	unseen_elapsed = 0.0
	target_visible = false
	perception_index = -1
	nearby = []
	perception_remaining = 0.0
	perception_ready = false
	vision_radius_squared = 0.0
	vision_cos = -1.0
