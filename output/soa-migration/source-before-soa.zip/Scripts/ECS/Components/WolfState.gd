class_name WolfState
extends Component

enum Strategy { FRONTAL, SIDE, REAR, HOWL }
const STRATEGY_NAMES := ["Frontal", "Side", "Rear", "Howl"]

var hunting: bool = false
var hunt_elapsed: float = 0.0
var charging: bool = false
var strategy: Strategy = Strategy.FRONTAL
var strategy_failures: Array[float] = [0.0, 0.0, 0.0, 0.0]
var retreating: bool = false
var resting: bool = false
var rest_elapsed: float = 0.0
var howl_elapsed: float = 1000.0
var howled: bool = false
var howl_pending: bool = false
var _nearest_threat: AnimalEntity
var _nearest_threat_generation: int = 0
var nearest_threat: AnimalEntity:
	get:
		if is_instance_valid(_nearest_threat) and _nearest_threat.identity.generation == _nearest_threat_generation and _nearest_threat.identity.alive:
			return _nearest_threat
		return null
	set(value):
		_nearest_threat = value
		_nearest_threat_generation = value.identity.generation if is_instance_valid(value) else 0

func reset() -> void:
	hunting = false
	hunt_elapsed = 0.0
	charging = false
	strategy = WolfState.Strategy.FRONTAL
	strategy_failures = [0.0, 0.0, 0.0, 0.0]
	nearest_threat = null
	retreating = false
	resting = false
	rest_elapsed = 0.0
	howl_elapsed = 1000.0
	howled = false
	howl_pending = false
