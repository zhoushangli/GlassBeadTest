class_name SheepState
extends Component

var local_flock_center := Vector2.ZERO
var neighbor_count: int = 0
var alignment := Vector2.ZERO
var threat_direction := Vector2.ZERO
var dog_pressure := Vector2.ZERO
var alert_elapsed: float = 0.0
var panic_elapsed: float = 0.0
var has_alert: bool = false
var has_panic: bool = false
var panic_source := Vector2.ZERO
var threatened: bool = false

func reset() -> void:
	local_flock_center = Vector2.ZERO
	neighbor_count = 0
	alignment = Vector2.ZERO
	threat_direction = Vector2.ZERO
	dog_pressure = Vector2.ZERO
	alert_elapsed = 0.0
	panic_elapsed = 0.0
	has_alert = false
	has_panic = false
	panic_source = Vector2.ZERO
	threatened = false
