class_name AnimalBrain
extends Component

var current_behavior: AnimalEntity.Behavior = AnimalEntity.Behavior.FLOCK
var view: AnimalView
var player: BTPlayer

func reset() -> void:
	current_behavior = AnimalEntity.Behavior.FLOCK
