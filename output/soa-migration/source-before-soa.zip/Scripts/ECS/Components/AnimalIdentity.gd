class_name AnimalIdentity
extends Component

var generation: int = 0
var entity_id: int = 0
var kind: AnimalEntity.Kind = AnimalEntity.Kind.SHEEP
var alive: bool = true
var death_remaining: float = 0.0

func reset() -> void:
	entity_id = 0
	kind = AnimalEntity.Kind.SHEEP
	alive = true
	death_remaining = 0.0
