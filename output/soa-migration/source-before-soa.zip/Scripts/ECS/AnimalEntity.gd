class_name AnimalEntity
extends Entity

enum Kind { SHEEP, WOLF, SHEEPDOG }
enum Behavior { FLOCK, ALERT, HERDED, FLEE, SEARCH, STALK, CHASE, PATROL, COLLECT, DRIVE, RETURN, REST, RETREAT, DEAD }

const BEHAVIOR_NAMES := [
	"Flock", "Alert", "Herded", "Flee", "Search", "Stalk", "Chase",
	"Patrol", "Collect", "Drive off", "Return", "Rest", "Retreat", "Dead"
]
const KIND_NAMES := ["Sheep", "Wolf", "Sheepdog"]

var identity: AnimalIdentity
var motion: AnimalMotion
var memory: AnimalMemory
var brain: AnimalBrain
var sheep_state: SheepState
var wolf_state: WolfState
var dog_state: SheepdogState
var settings: Resource
