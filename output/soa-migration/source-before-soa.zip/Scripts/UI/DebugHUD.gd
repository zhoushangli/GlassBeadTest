class_name DebugHUD
extends CanvasLayer

@onready var metrics: Label = $Screen/Header/Metrics
@onready var status: Label = $Screen/Header/Status
@onready var selection: Label = $Screen/Footer/Selection
@onready var parameters: RuntimeConfigPanel = $Screen/Parameters
@onready var debug_panel: DebugPanel = $Screen/DebugPanel
var gameplay_engine: Node

func initialize(engine: Node) -> void:
	gameplay_engine = engine
	parameters.initialize(engine)
	debug_panel.initialize(engine.debug_service)
	if not $Screen/Header/ParametersButton.pressed.is_connected(_toggle_parameters):
		$Screen/Header/ParametersButton.pressed.connect(_toggle_parameters)
		$Screen/Header/DebugButton.pressed.connect(_toggle_debug)
	refresh()

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_F2:
				_toggle_parameters()
				get_viewport().set_input_as_handled()
			KEY_F3:
				_toggle_debug()
				get_viewport().set_input_as_handled()
			KEY_ESCAPE:
				if debug_panel.visible:
					debug_panel.close()
					get_viewport().set_input_as_handled()
				elif parameters.visible:
					parameters.close()
					get_viewport().set_input_as_handled()

func _toggle_parameters() -> void:
	debug_panel.close()
	parameters.toggle()

func _toggle_debug() -> void:
	parameters.close()
	debug_panel.toggle()

func refresh() -> void:
	var counts: Vector3i = gameplay_engine.entity_service.get_counts()
	metrics.text = "FPS %d    |    Step %.2f ms    |    Alive %d    |    Sheep %d   Wolves %d   Dogs %d" % [
		Engine.get_frames_per_second(), gameplay_engine.profile_service.last_step_ms,
		counts.x + counts.y + counts.z, counts.x, counts.y, counts.z]
	var hunters: int = 0
	for wolf in gameplay_engine.entity_service.wolves:
		if wolf.identity.alive and wolf.wolf_state.hunting:
			hunters += 1
	status.text = "%s    |    Seed %d    |    Sim %.1f s    |    Captured %d    |    %s    |    Debug %s" % [
		"PAUSED" if gameplay_engine.paused else "RUNNING", gameplay_engine.config.random_seed,
		gameplay_engine.simulation_time, gameplay_engine.entity_service.capture_count,
		"Hunting %d" % hunters,
		"ON" if gameplay_engine.debug_service.show_details else "OFF"]
	selection.text = gameplay_engine.debug_service.selection_text()
	parameters.refresh()
	if debug_panel.visible:
		debug_panel.refresh()
