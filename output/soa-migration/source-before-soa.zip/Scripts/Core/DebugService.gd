class_name DebugService
extends Service

var hud: DebugHUD
var hud_enabled: bool = true
var overlay_enabled: bool = true
var _selected: AnimalEntity
var _selected_generation: int = 0
var selected: AnimalEntity:
	get:
		if is_instance_valid(_selected) and _selected.identity.alive and _selected.identity.generation == _selected_generation:
			return _selected
		return null
	set(value):
		_selected = value
		_selected_generation = value.identity.generation if is_instance_valid(value) else 0
var show_details: bool = false:
	set(value):
		show_details = value
		if not value:
			howl_events.clear()
		queue_redraw()
var selected_only: bool = true
var visual_options: Dictionary[String, bool] = {
	"sheep_vision": false, "wolf_vision": true, "dog_vision": true,
	"tracking": true, "memory": true, "movement": true,
	"protection": true, "howl": true,
}
var howl_events: Array[Dictionary] = []

func _startup() -> void:
	clear_selection()
	hud.initialize(g_gameplayEngine)

func _reset() -> void:
	clear_selection()
	howl_events.clear()

func _shutdown() -> void:
	clear_selection()
	howl_events.clear()
	hud = null

func _process(_delta: float) -> void:
	if not started or not g_gameplayEngine.running:
		return
	if overlay_enabled:
		refresh()
	if hud_enabled and is_instance_valid(hud):
		var started := Time.get_ticks_usec() if g_gameplayEngine.profile_service.performance_stats_enabled else 0
		hud.refresh()
		if g_gameplayEngine.profile_service.performance_stats_enabled:
			g_gameplayEngine.profile_service.record_debug_time("HUDRefresh", started)

func _unhandled_input(event: InputEvent) -> void:
	if not started or not g_gameplayEngine.running:
		return

	if event is InputEventKey and event.pressed and not event.echo:
		if get_viewport().gui_get_focus_owner() is LineEdit:
			return

		var key: int = event.physical_keycode if event.physical_keycode != 0 else event.keycode
		var amount := 10 if event.shift_pressed else 1
		match key:
			KEY_1:
				g_gameplayEngine.request_spawn(AnimalEntity.Kind.SHEEP, amount)
			KEY_2:
				g_gameplayEngine.request_spawn(AnimalEntity.Kind.WOLF, amount)
			KEY_3:
				g_gameplayEngine.request_spawn(AnimalEntity.Kind.SHEEPDOG, amount)
			KEY_SPACE:
				g_gameplayEngine.paused = not g_gameplayEngine.paused
			KEY_N:
				g_gameplayEngine.request_single_step()
			KEY_R:
				g_gameplayEngine.request_reset()
			KEY_F1:
				show_details = not show_details
			_:
				return
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		select_at(get_global_mouse_position())
		get_viewport().set_input_as_handled()

func select_at(point: Vector2) -> void:
	selected = null
	var nearest_distance: float = 19.0
	for animal in g_gameplayEngine.entity_service.entities:
		if animal.identity.alive:
			var distance := point.distance_to(animal.motion.position)
			if distance < nearest_distance:
				selected = animal
				nearest_distance = distance
	queue_redraw()

func clear_selection() -> void:
	selected = null
	queue_redraw()

func clear_invalid_selection() -> void:
	if not is_instance_valid(selected) or not selected.identity.alive:
		selected = null

func refresh() -> void:
	clear_invalid_selection()
	queue_redraw()

func selection_text() -> String:
	if not is_instance_valid(selected):
		return "Click an animal to inspect its behavior and target."
	var target_text := "none"
	if g_gameplayEngine.animal_system.is_live(selected, selected.memory.target):
		target_text = "%s #%d" % [AnimalEntity.KIND_NAMES[selected.memory.target.identity.kind], selected.memory.target.identity.entity_id]
	var text := "%s #%d  |  %s  |  Target: %s" % [
		AnimalEntity.KIND_NAMES[selected.identity.kind], selected.identity.entity_id,
		AnimalEntity.BEHAVIOR_NAMES[selected.brain.current_behavior], target_text]
	var details: String = g_gameplayEngine.debug_details(selected)
	if not details.is_empty():
		text += "  |  " + details
	return text

func set_visual_option(key: String, value: bool) -> void:
	visual_options[key] = value
	if key == "howl" and not value:
		howl_events.clear()
	queue_redraw()

func record_howl(animal: AnimalEntity) -> void:
	if not overlay_enabled or not show_details or not visual_options["howl"]:
		return
	if selected_only and selected != animal:
		return
	var view := animal.brain.view
	howl_events.append({
		"position": animal.motion.position, "radius": animal.settings.howl_radius,
		"duration": view.howl_visual_duration, "elapsed": 0.0,
		"color": view.howl_color, "id": animal.identity.entity_id,
		"generation": animal.identity.generation,
	})

func advance_visuals(delta: float) -> void:
	if not overlay_enabled or not show_details or not visual_options["howl"]:
		howl_events.clear()
		return
	for index in range(howl_events.size() - 1, -1, -1):
		howl_events[index]["elapsed"] += delta
		if howl_events[index]["elapsed"] >= howl_events[index]["duration"]:
			howl_events.remove_at(index)

func _draw() -> void:
	if not started or not g_gameplayEngine.running or not overlay_enabled:
		return
	var started_at := Time.get_ticks_usec() if g_gameplayEngine.profile_service.performance_stats_enabled else 0
	if selected != null:
		draw_arc(selected.motion.position, 17.0, 0.0, TAU, 40, Color("#f4f7ed"), 2.0, true)
	if show_details:
		if selected_only:
			if selected != null:
				_draw_animal(selected)
		else:
			for animal in g_gameplayEngine.entity_service.entities:
				if animal.enabled and animal.identity.alive:
					_draw_animal(animal)
		if visual_options["howl"]:
			for event in howl_events:
				if selected_only and (selected == null or selected.identity.generation != event["generation"]):
					continue
				var progress: float = clampf(event["elapsed"] / event["duration"], 0.0, 1.0)
				var color: Color = event["color"]
				color.a *= 1.0 - progress
				draw_circle(event["position"], event["radius"], Color(color, color.a * 0.08))
				draw_arc(event["position"], event["radius"], 0.0, TAU, 48, Color(color, color.a * 0.4), 1.0, true)
				draw_arc(event["position"], event["radius"] * progress, 0.0, TAU, 48, color, 2.0, true)
	if g_gameplayEngine.profile_service.performance_stats_enabled:
		g_gameplayEngine.profile_service.record_debug_time("OverlayDrawCPUTime", started_at)

func _draw_animal(animal: AnimalEntity) -> void:
	var point := animal.motion.position
	var view := animal.brain.view
	var width := view.debug_line_width
	var vision_key: String = ["sheep_vision", "wolf_vision", "dog_vision"][animal.identity.kind]
	if visual_options[vision_key]:
		var half_angle: float = deg_to_rad(animal.settings.vision_angle * 0.5)
		var radius: float = animal.settings.perception_radius
		var direction := animal.motion.facing.angle()
		var points := PackedVector2Array([point])
		for index in range(33):
			points.append(point + Vector2.from_angle(direction - half_angle + 2.0 * half_angle * index / 32.0) * radius)
		draw_colored_polygon(points, view.vision_color)
		var edge := Color(view.vision_color, 0.5)
		draw_arc(point, radius, direction - half_angle, direction + half_angle, 32, edge, width, true)
		draw_line(point, points[1], edge, width, true)
		draw_line(point, points[-1], edge, width, true)
	var memory := animal.memory
	if memory.target != null:
		if visual_options["tracking"]:
			if memory.target_visible:
				draw_line(point, memory.last_seen_position, Color(view.base_color, 0.5), width, true)
			else:
				draw_dashed_line(point, memory.last_seen_position, Color(view.base_color, 0.5), width, 6.0)
		if visual_options["memory"] and not memory.target_visible:
			var remaining: float = clampf(1.0 - memory.unseen_elapsed / maxf(animal.settings.memory_duration, 0.00001), 0.0, 1.0)
			var color := Color(view.base_color, remaining)
			draw_arc(memory.last_seen_position, 7.0, 0.0, TAU, 20, color, width, true)
			draw_line(memory.last_seen_position - Vector2(4, 0), memory.last_seen_position + Vector2(4, 0), color, width)
			draw_line(memory.last_seen_position - Vector2(0, 4), memory.last_seen_position + Vector2(0, 4), color, width)
	if visual_options["movement"]:
		if not visual_options["tracking"] or memory.target == null or not animal.motion.movement_goal.is_equal_approx(memory.last_seen_position):
			draw_line(point, animal.motion.movement_goal, Color("#f4f7ed"), width, true)
		draw_circle(animal.motion.movement_goal, 3.0, Color("#f4f7ed"))
	if visual_options["protection"] and animal.dog_state != null:
		var state := animal.dog_state
		draw_arc(state.protection_center, animal.settings.local_flock_radius, 0.0, TAU, 48, Color("#93c5fd"), width, true)
		draw_circle(state.protection_center, 4.0, Color("#93c5fd"))
		draw_circle(state.guard_point, 4.0, Color("#93c5fd"), false, width, true)
		if state.collected_sheep != null:
			draw_dashed_line(point, state.collected_sheep.motion.position, Color("#4de6b3"), width, 6.0)
