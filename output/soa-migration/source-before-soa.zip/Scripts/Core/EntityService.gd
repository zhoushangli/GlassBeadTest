class_name EntityService
extends Service

const SPATIAL_CELL_SIZE: float = 120.0

@export var sheep_scene: PackedScene
@export var wolf_scene: PackedScene
@export var sheepdog_scene: PackedScene

var entities: Array[AnimalEntity] = []
var sheep: Array[AnimalEntity] = []
var wolves: Array[AnimalEntity] = []
var dogs: Array[AnimalEntity] = []
var container: Node2D
var next_id: int = 1
var capture_count: int = 0
var all_entities: Array[AnimalEntity] = []
var dying: Array[AnimalEntity] = []
var pools: Array[Array] = [[], [], []]
var _generation: int = 0
var perception_positions := PackedVector2Array()
var perception_velocities := PackedVector2Array()
var perception_kinds := PackedInt32Array()
var _spatial_cells: Dictionary[Vector2i, Array] = {}
var spatial_stats_enabled: bool = OS.is_debug_build()
var spatial_query_count: int = 0
var spatial_candidate_count: int = 0
var spatial_max_candidates: int = 0
var spatial_nonempty_cells: int = 0
var spatial_max_occupancy: int = 0

func _reset() -> void:
	for animal in all_entities:
		_deactivate(animal)
		animal.brain.view.hide()
	entities.clear()
	sheep.clear()
	wolves.clear()
	dogs.clear()
	dying.clear()
	for pool in pools:
		pool.clear()
	for animal in all_entities:
		pools[animal.identity.kind].append(animal)
	_clear_snapshot()
	next_id = 1
	capture_count = 0

func _shutdown() -> void:
	clear()
	container = null

func spawn(kind: AnimalEntity.Kind, count: int, at_position := Vector2.INF) -> Array[AnimalEntity]:
	var result: Array[AnimalEntity] = []
	var scene: PackedScene = [sheep_scene, wolf_scene, sheepdog_scene][kind]
	if scene == null or not is_instance_valid(container):
		push_error("EntityService requires animal prefabs and an entity container.")
		return result

	for index in range(count):
		var animal: AnimalEntity
		if pools[kind].is_empty():
			animal = _create(kind, scene)
		else:
			animal = pools[kind].pop_front()
		var spawn_position: Vector2 = at_position
		if spawn_position == Vector2.INF:
			spawn_position = g_gameplayEngine.random_position()
		_initialize_animal(animal, kind, spawn_position)
		next_id += 1
		entities.append(animal)
		match kind:
			AnimalEntity.Kind.SHEEP:
				sheep.append(animal as AnimalEntity)
			AnimalEntity.Kind.WOLF:
				wolves.append(animal as AnimalEntity)
			AnimalEntity.Kind.SHEEPDOG:
				dogs.append(animal as AnimalEntity)
		result.append(animal)

	return result

func _create(kind: AnimalEntity.Kind, scene: PackedScene) -> AnimalEntity:
	var animal := AnimalEntity.new()
	animal.identity = AnimalIdentity.new()
	animal.motion = AnimalMotion.new()
	animal.memory = AnimalMemory.new()
	animal.brain = AnimalBrain.new()
	animal.add_components([animal.identity, animal.motion, animal.memory, animal.brain])
	match kind:
		AnimalEntity.Kind.SHEEP:
			animal.sheep_state = SheepState.new()
			animal.add_component(animal.sheep_state)
		AnimalEntity.Kind.WOLF:
			animal.wolf_state = WolfState.new()
			animal.add_component(animal.wolf_state)
		AnimalEntity.Kind.SHEEPDOG:
			animal.dog_state = SheepdogState.new()
			animal.add_component(animal.dog_state)
	var view := scene.instantiate() as AnimalView
	view.entity = animal
	container.add_child(view)
	animal.brain.view = view
	animal.brain.player = view.bt_player
	g_gameplayEngine.ecs_world.add_entity(animal)
	all_entities.append(animal)
	return animal

func _initialize_animal(animal: AnimalEntity, kind: AnimalEntity.Kind, point: Vector2) -> void:
	animal.brain.view.reset_tree()
	for component: Component in animal.components.values():
		component.call("reset")
	_generation += 1
	animal.identity.generation = _generation
	animal.identity.entity_id = next_id
	animal.identity.kind = kind
	animal.motion.position = point
	animal.motion.movement_goal = point
	animal.motion.wander_point = point
	animal.motion.facing = Vector2.from_angle(g_gameplayEngine.rng.randf_range(-PI, PI))
	if kind != AnimalEntity.Kind.SHEEP:
		animal.brain.current_behavior = AnimalEntity.Behavior.PATROL
	if animal.dog_state != null:
		animal.dog_state.protection_center = point
		animal.dog_state.patrol_angle = next_id * 2.399963
	g_gameplayEngine.refresh_animal_config(animal)
	if not animal.enabled:
		g_gameplayEngine.ecs_world.enable_entity(animal)
	animal.brain.player.active = true
	animal.brain.view.show()
	animal.brain.view.sync()

func spawn_initial() -> void:
	var settings: SimulationConfig = g_gameplayEngine.config
	var center: Vector2 = settings.arena_size * 0.5
	for index in range(settings.initial_sheep):
		var point := center + Vector2(
			g_gameplayEngine.rng.randf_range(-440.0, 440.0),
			g_gameplayEngine.rng.randf_range(-220.0, 220.0))
		spawn(AnimalEntity.Kind.SHEEP, 1, point)

	for index in range(settings.initial_wolves):
		var point: Vector2 = g_gameplayEngine.random_position()
		if index % 2 == 0:
			point.x = 40.0
		else:
			point.x = settings.arena_size.x - 40.0
		spawn(AnimalEntity.Kind.WOLF, 1, point)

	for index in range(settings.initial_sheepdogs):
		var angle := TAU * float(index) / maxf(1.0, settings.initial_sheepdogs)
		spawn(AnimalEntity.Kind.SHEEPDOG, 1, center + Vector2.from_angle(angle) * 100.0)

func rebuild_spatial_index() -> void:
	reset_spatial_stats()
	_spatial_cells.clear()
	perception_positions.resize(entities.size())
	perception_kinds.resize(entities.size())
	perception_velocities.resize(entities.size())

	for index in range(entities.size()):
		var animal := entities[index]
		if not animal.enabled or not animal.identity.alive:
			continue

		var point := animal.motion.position
		animal.memory.perception_index = index
		perception_positions[index] = point
		perception_velocities[index] = animal.motion.velocity
		perception_kinds[index] = animal.identity.kind
		var cell := Vector2i((point / SPATIAL_CELL_SIZE).floor())
		if not _spatial_cells.has(cell):
			_spatial_cells[cell] = []
		_spatial_cells[cell].append(index)
		if spatial_stats_enabled:
			spatial_max_occupancy = maxi(spatial_max_occupancy, _spatial_cells[cell].size())
	if spatial_stats_enabled:
		spatial_nonempty_cells = _spatial_cells.size()

func reset_spatial_stats() -> void:
	spatial_query_count = 0
	spatial_candidate_count = 0
	spatial_max_candidates = 0
	spatial_nonempty_cells = 0
	spatial_max_occupancy = 0

func get_nearby_indices(point: Vector2, radius: float) -> Array[int]:
	var started := Time.get_ticks_usec() if g_gameplayEngine.profile_service.detailed_stats_enabled else 0
	var nearby: Array[int] = []
	var first := Vector2i(((point - Vector2.ONE * radius) / SPATIAL_CELL_SIZE).floor())
	var last := Vector2i(((point + Vector2.ONE * radius) / SPATIAL_CELL_SIZE).floor())
	for y in range(first.y, last.y + 1):
		for x in range(first.x, last.x + 1):
			var cell := Vector2i(x, y)
			if _spatial_cells.has(cell):
				nearby.append_array(_spatial_cells[cell])

	if spatial_stats_enabled:
		spatial_query_count += 1
		spatial_candidate_count += nearby.size()
		spatial_max_candidates = maxi(spatial_max_candidates, nearby.size())
	if g_gameplayEngine.profile_service.detailed_stats_enabled:
		g_gameplayEngine.profile_service.record_hotspot("NearbyQuery", started)
	return nearby

func get_counts() -> Vector3i:
	var counts := Vector3i.ZERO
	for animal in entities:
		if animal.identity.alive:
			counts[animal.identity.kind] += 1
	return counts

func capture(prey: AnimalEntity) -> bool:
	if not is_instance_valid(prey) or not prey.identity.alive or prey.identity.kind != AnimalEntity.Kind.SHEEP:
		return false

	prey.identity.alive = false
	prey.identity.death_remaining = g_gameplayEngine.config.death_duration
	prey.brain.view.reset_tree()
	prey.memory.target = null
	prey.motion.velocity = Vector2.ZERO
	prey.motion.desired_velocity = Vector2.ZERO
	prey.brain.current_behavior = AnimalEntity.Behavior.DEAD
	prey.brain.view.sync()
	dying.append(prey)
	# 1) Invalidate interactions immediately; defer enabled-query changes until the safe boundary.
	capture_count += 1
	g_gameplayEngine.debug_service.clear_invalid_selection()
	return true

func remove_expired(delta: float = 0.0) -> void:
	for index in range(dying.size() - 1, -1, -1):
		var animal := dying[index]
		if animal.enabled:
			_deactivate(animal)
			entities.erase(animal)
			[sheep, wolves, dogs][animal.identity.kind].erase(animal)
		animal.identity.death_remaining -= delta
		if animal.identity.death_remaining <= 0.0:
			animal.brain.view.hide()
			pools[animal.identity.kind].append(animal)
			dying.remove_at(index)

func _deactivate(animal: AnimalEntity) -> void:
	animal.identity.alive = false
	animal.brain.view.reset_tree()
	if animal.enabled:
		g_gameplayEngine.ecs_world.disable_entity(animal)

func clear() -> void:
	for animal in all_entities:
		animal.brain.view.entity = null
		animal.brain.view.queue_free()
		g_gameplayEngine.ecs_world.remove_entity(animal)
	all_entities.clear()
	dying.clear()
	for pool in pools:
		pool.clear()
	entities.clear()
	sheep.clear()
	wolves.clear()
	dogs.clear()
	_clear_snapshot()
	next_id = 1
	capture_count = 0

func _clear_snapshot() -> void:
	_spatial_cells.clear()
	perception_positions.clear()
	perception_velocities.clear()
	perception_kinds.clear()
	reset_spatial_stats()
