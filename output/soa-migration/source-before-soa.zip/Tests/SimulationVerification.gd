extends SceneTree

var checks: int = 0
var failures: int = 0
var engine: Node
var scene: Node
var authored: Resource

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + label)

func _empty(frozen: bool = true) -> void:
	engine.config = authored.copy_config()
	engine.config.initial_sheep = 0
	engine.config.initial_wolves = 0
	engine.config.initial_sheepdogs = 0
	engine.config.perception_interval = 0.0
	if frozen:
		engine.config.sheep.move_speed = 0.0
		engine.config.sheep.flee_speed = 0.0
		engine.config.wolf.move_speed = 0.0
		engine.config.wolf.chase_speed = 0.0
		engine.config.wolf.retreat_speed = 0.0
		engine.config.sheepdog.move_speed = 0.0
		engine.config.sheepdog.drive_speed = 0.0
		engine.config.sheepdog.return_speed = 0.0
	engine.reset_simulation()
	engine.paused = true

func _animal(kind: AnimalEntity.Kind, point: Vector2) -> AnimalEntity:
	return engine.entity_service.spawn(kind, 1, point)[0]

func _step(count: int) -> void:
	for index in range(count):
		engine.simulate_step(1.0 / 60.0)

func _key(code: Key, shift: bool = false, echo: bool = false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.keycode = code
	event.pressed = true
	event.shift_pressed = shift
	event.echo = echo
	engine.debug_service._unhandled_input(event)

func _verify_resources_and_vision() -> void:
	_empty()
	_check(authored.validate().is_empty(), "authored CFG validates")
	var copy: SimulationConfig = authored.copy_config()
	copy.sheep.move_speed = 19.0
	_check(authored.sheep.move_speed == 70.0, "runtime resources are independent")
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(400, 300))
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300))
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(400, 300))
	for animal in [sheep, wolf, dog]:
		_check(animal.brain.player.get_bt_instance() != null and animal.brain.player.update_mode == BTPlayer.MANUAL, "manual behavior tree is instantiated")
		animal.motion.facing = Vector2.RIGHT
		var radius: float = animal.settings.perception_radius
		var half: float = deg_to_rad(animal.settings.vision_angle * 0.5)
		_check(g_gameplayEngine.animal_system.can_see(animal, animal.motion.position), "coincident target visible")
		_check(g_gameplayEngine.animal_system.can_see(animal, animal.motion.position + Vector2.RIGHT * radius), "range boundary visible")
		_check(not g_gameplayEngine.animal_system.can_see(animal, animal.motion.position + Vector2.RIGHT * (radius + 1.0)), "outside visual range rejected")
		_check(g_gameplayEngine.animal_system.can_see(animal, animal.motion.position + Vector2.from_angle(half) * 50.0), "angle boundary visible")
		_check(not g_gameplayEngine.animal_system.can_see(animal, animal.motion.position + Vector2.from_angle(half + 0.01) * 50.0), "outside visual angle rejected")
		animal.motion.velocity = Vector2.ZERO
		animal.motion.desired_velocity = Vector2.ZERO
		animal.motion.separation = Vector2.ZERO
		animal.motion.speed_limit = 0.0
		g_gameplayEngine.animal_system.move(animal, 1.0 / 60.0)
		_check(animal.motion.facing == Vector2.RIGHT, "stationary facing retained")
	wolf.motion.desired_velocity = Vector2.DOWN * 50.0
	wolf.motion.speed_limit = 50.0
	g_gameplayEngine.animal_system.move(wolf, 1.0 / 60.0)
	wolf.brain.view.sync()
	_check(wolf.motion.facing.is_equal_approx(Vector2.DOWN) and is_equal_approx(wolf.brain.view.sprite.rotation, PI), "sprite and facing follow actual movement")
	engine.debug_service.select_at(sheep.motion.position)
	engine.entity_service.capture(sheep)
	_check(not sheep.identity.alive and not engine.entity_service.capture(sheep), "death is idempotent")
	_step(20)
	_check(not engine.entity_service.entities.has(sheep), "corpse removed from registry")

func _verify_sheep() -> void:
	_empty()
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(400, 300)) as AnimalEntity
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(300, 300)) as AnimalEntity
	sheep.motion.facing = Vector2.RIGHT
	wolf.wolf_state.resting = true
	wolf.wolf_state.rest_elapsed = -100.0
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.FLOCK, "hidden distant wolf does not affect sheep")
	wolf.motion.position = Vector2(380, 300)
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.FLEE, "emergency radius bypasses vision")
	wolf.motion.position = Vector2(100, 500)
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.ALERT, "lost threat becomes alert")
	engine.config.sheep.alert_duration = 0.02
	_step(2)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.FLOCK, "alert expires")
	g_gameplayEngine.sheep_system.receive_howl(sheep, Vector2(350, 300))
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.FLEE and sheep.sheep_state.threat_direction.x > 0.0, "howl causes outward panic")
	sheep.sheep_state.panic_elapsed = 1.0
	g_gameplayEngine.sheep_system.receive_howl(sheep, Vector2(350, 300))
	_check(sheep.sheep_state.panic_elapsed == 0.0, "repeated howl refreshes panic")
	engine.config.sheep.panic_duration = 0.01
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.ALERT, "panic becomes alert")
	_empty(false)
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(400, 300)) as AnimalEntity
	var neighbor := _animal(AnimalEntity.Kind.SHEEP, Vector2(440, 300))
	neighbor.motion.velocity = Vector2.DOWN * 20.0
	engine.entity_service.rebuild_spatial_index()
	neighbor.motion.velocity = Vector2.UP * 20.0
	g_gameplayEngine.perceive_animal(sheep, 1.0 / 60.0)
	_check(sheep.sheep_state.neighbor_count == 1 and sheep.sheep_state.alignment.y > 0.0, "BOID reads snapshot velocity")
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(350, 300))
	engine.entity_service.rebuild_spatial_index()
	g_gameplayEngine.perceive_animal(sheep, 1.0 / 60.0)
	g_gameplayEngine.animal_system.decide(sheep, 1.0 / 60.0)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.HERDED and sheep.motion.desired_velocity.x > 0.0, "dog pushes sheep away")
	dog.motion.position = Vector2(100, 500)

func _verify_wolves() -> void:
	_empty()
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(550, 300))
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	_step(1)
	_check(wolf.wolf_state.hunting and wolf.memory.target == sheep and wolf.brain.current_behavior == AnimalEntity.Behavior.STALK, "visible nearest sheep starts stalk")
	wolf.wolf_state.strategy = WolfState.Strategy.FRONTAL
	var seen := wolf.memory.last_seen_position
	sheep.motion.position = Vector2(300, 350)
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.SEARCH and wolf.memory.last_seen_position == seen and wolf.motion.movement_goal == seen, "hidden prey only updates unseen timer")
	sheep.motion.position = Vector2(550, 310)
	_step(1)
	_check(wolf.memory.target_visible and wolf.memory.unseen_elapsed == 0.0 and wolf.memory.last_seen_position == sheep.motion.position, "reacquired prey refreshes memory")
	sheep.motion.position = Vector2(300, 350)
	engine.config.wolf.memory_duration = 0.02
	_step(2)
	_check(not wolf.wolf_state.hunting and wolf.brain.current_behavior == AnimalEntity.Behavior.REST and wolf.wolf_state.strategy_failures[0] > 0.9, "lost memory fails hunt once and rests")
	var failures_before: float = wolf.wolf_state.strategy_failures[0]
	g_gameplayEngine.wolf_system.end_hunt(wolf, false)
	_check(wolf.wolf_state.strategy_failures[0] == failures_before, "failure feedback is idempotent")
	engine.config.wolf.rest_duration = 0.01
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.PATROL, "rest ends into patrol without visible prey")
	_empty()
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(420, 300))
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	_step(1)
	_check(not sheep.identity.alive and engine.entity_service.capture_count == 1 and wolf.wolf_state.resting, "charge immediately captures in range and rests")
	_empty()
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(420, 300))
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	var second := _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	second.motion.facing = Vector2.RIGHT
	_step(1)
	_check(engine.entity_service.capture_count == 1, "multiple wolves cannot double capture")
	_empty()
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(420, 300))
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	g_gameplayEngine.wolf_system.begin_hunt(wolf, sheep)
	g_gameplayEngine.animal_system.set_behavior(wolf, AnimalEntity.Behavior.CHASE)
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(380, 300))
	g_gameplayEngine.wolf_system.resolve_interactions(wolf, 0.0)
	_check(sheep.identity.alive and not wolf.wolf_state.hunting and wolf.wolf_state.retreating, "post-movement dog interrupts capture from behind")
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.RETREAT, "tree prioritizes retreat")
	dog.motion.position = Vector2(100, 500)
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.REST and not wolf.wolf_state.retreating, "cleared retreat starts rest")
	_empty()
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(550, 300))
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	g_gameplayEngine.wolf_system.begin_hunt(wolf, sheep)
	wolf.wolf_state.strategy = WolfState.Strategy.HOWL
	_step(1)
	_check(wolf.wolf_state.howled and (sheep as AnimalEntity).sheep_state.has_panic and sheep.brain.current_behavior != AnimalEntity.Behavior.FLEE, "howl is delivered after decisions")
	_step(1)
	_check(sheep.brain.current_behavior == AnimalEntity.Behavior.FLEE, "howl affects next decision")
	var elapsed: float = (sheep as AnimalEntity).sheep_state.panic_elapsed
	_step(1)
	_check((sheep as AnimalEntity).sheep_state.panic_elapsed > elapsed, "one hunt does not howl repeatedly")
	g_gameplayEngine.wolf_system.end_hunt(wolf, true)
	_check(wolf.wolf_state.strategy_failures[WolfState.Strategy.HOWL] == 0.0, "success feedback stays nonnegative")

func _verify_dogs() -> void:
	_empty()
	var anchor := _animal(AnimalEntity.Kind.SHEEP, Vector2(500, 300)) as AnimalEntity
	var stray := _animal(AnimalEntity.Kind.SHEEP, Vector2(680, 300)) as AnimalEntity
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(600, 300)) as AnimalEntity
	dog.dog_state.protected_sheep = anchor
	dog.dog_state.assignment_remaining = 100.0
	dog.motion.facing = Vector2.RIGHT
	_step(1)
	_check(dog.dog_state.collected_sheep == stray and dog.brain.current_behavior == AnimalEntity.Behavior.COLLECT, "local stray is collected")
	_check(dog.motion.movement_goal.x > stray.motion.position.x, "collect point is outside stray relative to flock")
	stray.motion.position = Vector2(570, 300)
	_step(1)
	_check(dog.dog_state.collected_sheep == null and dog.brain.current_behavior == AnimalEntity.Behavior.PATROL, "collected sheep releases task")
	var guard := dog.dog_state.guard_point
	_step(1)
	_check(dog.dog_state.guard_point != guard, "patrol target rotates over simulation time")
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(700, 300)) as AnimalEntity
	wolf.wolf_state.resting = true
	wolf.wolf_state.rest_elapsed = -100.0
	_step(1)
	_check(dog.memory.target == wolf and dog.brain.current_behavior == AnimalEntity.Behavior.DRIVE, "visible nearby wolf interrupts patrol")
	var seen := dog.memory.last_seen_position
	wolf.motion.position = Vector2(300, 500)
	_step(1)
	_check(dog.memory.target == wolf and dog.memory.last_seen_position == seen and dog.motion.movement_goal == seen, "dog pursues last visible position")
	engine.config.sheepdog.memory_duration = 0.02
	_step(2)
	_check(dog.memory.target == null and dog.brain.current_behavior == AnimalEntity.Behavior.RETURN, "dog returns when memory expires")
	dog.motion.position = Vector2(1000, 300)
	_step(1)
	_check(dog.brain.current_behavior == AnimalEntity.Behavior.RETURN, "leash takes priority")
	_empty()
	anchor = _animal(AnimalEntity.Kind.SHEEP, Vector2(500, 300)) as AnimalEntity
	dog = _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(580, 300)) as AnimalEntity
	var other := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(580, 300)) as AnimalEntity
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(670, 300)) as AnimalEntity
	wolf.wolf_state.resting = true
	wolf.wolf_state.rest_elapsed = -100.0
	for item in [dog, other]:
		item.dog_state.protected_sheep = anchor
		item.dog_state.assignment_remaining = 100.0
		item.motion.facing = Vector2.RIGHT
	_step(1)
	_check(dog.memory.target == wolf and other.memory.target == null, "equal distance wolf claim uses lower dog ID")
	engine.entity_service.dogs.reverse()
	_step(1)
	_check(dog.memory.target == wolf and other.memory.target == null, "wolf claim independent of dog registry order")
	wolf.motion.position = Vector2(100, 500)
	dog.memory.target = null
	other.memory.target = null
	stray = _animal(AnimalEntity.Kind.SHEEP, Vector2(700, 300)) as AnimalEntity
	_step(1)
	_check(dog.dog_state.collected_sheep == stray and other.dog_state.collected_sheep == null, "stray gets one responsible dog")
	_empty()
	dog = _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(400, 300)) as AnimalEntity
	_step(1)
	_check(dog.brain.current_behavior == AnimalEntity.Behavior.PATROL and dog.memory.target == null, "no sheep falls back to wandering")

func _verify_behavior_edges() -> void:
	_empty()
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(470, 300))
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.CHASE, "close prey enters charge")
	sheep.motion.position = Vector2(550, 300)
	_step(1)
	_check(wolf.brain.current_behavior == AnimalEntity.Behavior.CHASE, "charge persists when prey moves farther away")
	wolf.wolf_state.hunt_elapsed = engine.config.wolf.hunt_duration
	_step(1)
	_check(not wolf.wolf_state.hunting and wolf.brain.current_behavior == AnimalEntity.Behavior.REST, "hunt timeout interrupts charge")
	_empty()
	sheep = _animal(AnimalEntity.Kind.SHEEP, Vector2(550, 300))
	wolf = _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300)) as AnimalEntity
	wolf.motion.facing = Vector2.RIGHT
	var nearer := _animal(AnimalEntity.Kind.SHEEP, Vector2(530, 300))
	_step(1)
	_check(wolf.memory.target == nearer, "nearest visible sheep selected")
	engine.entity_service.capture(nearer)
	_step(1)
	_check(not wolf.wolf_state.hunting and wolf.wolf_state.resting, "target death ends hunt immediately")
	wolf.wolf_state.strategy_failures = [1000.0, 0.0, 1000.0, 1000.0]
	var sides: int = 0
	for index in range(200):
		g_gameplayEngine.wolf_system.begin_hunt(wolf, sheep)
		if wolf.wolf_state.strategy == WolfState.Strategy.SIDE:
			sides += 1
	_check(sides > 190, "feedback strongly favors the strategy with fewer failures")
	g_gameplayEngine.wolf_system.end_hunt(wolf, false)
	wolf.wolf_state.strategy_failures[0] = 2.0
	var before: float = wolf.wolf_state.strategy_failures[0]
	_step(1)
	_check(wolf.wolf_state.strategy_failures[0] < before, "strategy failures decay with simulation time")
	_empty(false)
	engine.config.sheep.idle_speed_scale = 0.0
	engine.config.sheep.alignment_weight = 0.0
	engine.config.sheep.cohesion_weight = 0.0
	var anchor := _animal(AnimalEntity.Kind.SHEEP, Vector2(500, 300)) as AnimalEntity
	var stray := _animal(AnimalEntity.Kind.SHEEP, Vector2(680, 300)) as AnimalEntity
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(755, 300)) as AnimalEntity
	dog.dog_state.protected_sheep = anchor
	dog.dog_state.assignment_remaining = 1000.0
	var collected := false
	for index in range(600):
		_step(1)
		if anchor.motion.position.distance_to(stray.motion.position) < engine.config.sheepdog.local_flock_radius:
			collected = true
			break
	_check(collected, "dog pressure actually brings a stray back to local companions")
	_empty()
	anchor = _animal(AnimalEntity.Kind.SHEEP, Vector2(500, 300)) as AnimalEntity
	dog = _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(600, 300)) as AnimalEntity
	var other := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(600, 300)) as AnimalEntity
	var first := _animal(AnimalEntity.Kind.WOLF, Vector2(650, 280)) as AnimalEntity
	var second := _animal(AnimalEntity.Kind.WOLF, Vector2(650, 320)) as AnimalEntity
	for predator in [first, second]:
		predator.wolf_state.resting = true
		predator.wolf_state.rest_elapsed = -100.0
	for guard in [dog, other]:
		guard.motion.facing = Vector2.RIGHT
		guard.dog_state.protected_sheep = anchor
		guard.dog_state.assignment_remaining = 100.0
	_step(1)
	_check(dog.memory.target == first and other.memory.target == second, "loser of shared wolf claim takes remaining threat")

func _verify_runtime_config() -> void:
	_empty()
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(400, 300)) as AnimalEntity
	g_gameplayEngine.sheep_system.receive_howl(sheep, Vector2(300, 300))
	_step(1)
	var panel: RuntimeConfigPanel = scene.hud.parameters
	panel.set_draft(engine.config)
	_check(panel.editors.has("Sheep.alignment_weight") and panel.editors.has("Wolves.howl_radius") and panel.editors.has("Dogs.vision_angle"), "new CFG fields exposed")
	var draft: SimulationConfig = engine.config.copy_config()
	draft.sheep.emergency_distance = draft.sheep.perception_radius + 1.0
	_check(not draft.validate().is_empty(), "invalid emergency range rejected")
	draft = engine.config.copy_config()
	draft.sheepdog.guard_distance = draft.sheepdog.leash_distance
	_check(not draft.validate().is_empty(), "invalid leash rejected")
	draft = engine.config.copy_config()
	draft.sheepdog.collect_distance = draft.sheep.herding_distance
	_check(not draft.validate().is_empty(), "collect point must exert sheep pressure")
	draft = engine.config.copy_config()
	draft.sheep.vision_angle = 250.0
	var elapsed := sheep.sheep_state.panic_elapsed
	_check(engine.request_config_apply(draft).is_empty(), "ordinary config accepted")
	engine._process(0.0)
	_check(sheep.settings.vision_angle == 250.0 and sheep.sheep_state.panic_elapsed == elapsed and engine.paused, "paused hot apply preserves timers")
	var path := "res://output/verification/preset_v3.tres"
	_check(engine.save_preset(path) == OK and engine.load_preset(path) != null, "new preset round trip")
	var old: SimulationConfig = engine.config.copy_config()
	old.preset_version = 2
	var old_path := "res://output/verification/preset_old.tres"
	ResourceSaver.save(old, old_path)
	var before := FileAccess.get_file_as_string(old_path)
	_check(engine.load_preset(old_path) == null and FileAccess.get_file_as_string(old_path) == before, "old preset rejected unchanged")
	draft = engine.config.copy_config()
	draft.initial_sheep = 1
	draft.arena_size = Vector2(1400, 800)
	engine.request_config_apply(draft)
	engine._process(0.0)
	_check(engine.paused and engine.entity_service.get_counts() == Vector3i(1, 0, 0), "restart preserves pause and uses new counts")
	_check(scene.get_node("Camera2D").position == Vector2(700, 400), "arena refresh independent of removed food system")

func _verify_controls() -> void:
	_empty()
	_key(KEY_1)
	_key(KEY_2, true)
	_key(KEY_3)
	engine._process(0.0)
	_check(engine.entity_service.get_counts() == Vector3i(1, 10, 1), "debug spawn and batch keys")
	var before: int = engine.step_count
	engine._process(1.0)
	_check(engine.step_count == before, "pause freezes simulation")
	_key(KEY_N)
	engine._process(0.0)
	_check(engine.step_count == before + 1 and engine.paused, "single step advances once")
	engine._process(0.0)
	_check(engine.step_count == before + 1, "single step is consumed")
	_key(KEY_1, false, true)
	engine._process(0.0)
	_check(engine.entity_service.get_counts().x == 1, "key repeats are ignored")

	var panel: RuntimeConfigPanel = scene.hud.parameters
	panel.show()
	panel.set_draft(engine.config)
	panel.editors["World.initial_sheep"].get_line_edit().grab_focus()
	_key(KEY_1)
	_key(KEY_R)
	engine._process(0.0)
	_check(engine.entity_service.get_counts() == Vector3i(1, 10, 1), "numeric field focus blocks gameplay shortcuts")
	panel.close()
	_key(KEY_F1)
	_check(engine.debug_service.show_details, "debug overlay toggle")

	engine.config = authored.copy_config()
	engine.reset_simulation()
	var positions: Array[Vector2] = []
	for animal in engine.entity_service.entities:
		positions.append(animal.motion.position)
	_step(3)
	engine.reset_simulation()
	var repeated: Array[Vector2] = []
	for animal in engine.entity_service.entities:
		repeated.append(animal.motion.position)
	_check(positions == repeated, "reset reproduces seeded populations")
	_check(engine.step_count == 0 and engine.entity_service.capture_count == 0, "reset clears simulation counters")
	_check(engine.entity_service.get_counts() == Vector3i(240, 24, 12), "default population remains unchanged")

func _verify_clock() -> void:
	_empty(false)
	engine.simulation_hz = 60.0
	engine.max_steps_per_frame = 4
	engine.paused = false
	var interval: float = 1.0 / engine.simulation_hz
	engine._process(interval * 0.4)
	_check(engine.step_count == 0 and is_equal_approx(engine._accumulator, interval * 0.4), "fractional frame waits for a full step")
	engine._process(interval * 0.6)
	_check(engine.step_count == 1 and is_zero_approx(engine._accumulator), "accumulated full step advances once")
	engine.reset_simulation()
	engine._process(interval * 6.4)
	_check(engine.step_count == 4 and is_equal_approx(engine._accumulator, interval * 0.4), "catch-up is bounded and retains only fractional remainder")
	engine._process(0.0)
	_check(engine.step_count == 4, "discarded backlog is not replayed")
	engine._process(interval * 0.6)
	_check(engine.step_count == 5, "fractional remainder carries into next frame")
	engine.reset_simulation()
	engine._process(interval * 0.4)
	engine.paused = true
	engine._process(100.0)
	_check(engine.step_count == 0 and engine._accumulator == 0.0, "pause discards fractional time and accrues no debt")
	engine.paused = false
	engine._process(interval * 0.6)
	_check(engine.step_count == 0, "resume starts with a fresh accumulator")
	engine._process(interval * 0.4)
	_check(engine.step_count == 1, "resume advances after a new full interval")
	engine.reset_simulation()
	engine.simulation_hz = 30.0
	engine.paused = true
	engine.request_single_step()
	engine._process(0.0)
	_check(engine.step_count == 1 and is_equal_approx(engine.simulation_time, 1.0 / 30.0), "single step uses configured interval")
	engine._process(10.0)
	_check(engine.step_count == 1, "single-step request is consumed once")
	engine.paused = false
	engine._process(0.01)
	engine.reset_simulation()
	_check(engine._accumulator == 0.0 and engine.step_count == 0, "reset clears accumulated time")
	var errors_enabled := Engine.print_error_messages
	Engine.print_error_messages = false
	var invalid_results: Array[bool] = []
	for frequency in [0.0, -1.0, NAN, INF, 1.0e-320]:
		engine.simulation_hz = frequency
		engine._process(1.0)
		invalid_results.append(engine.step_count == 0 and engine._clock_error_reported)
	engine.simulation_hz = 60.0
	engine.max_steps_per_frame = 0
	engine._process(1.0)
	invalid_results.append(engine.step_count == 0 and engine._clock_error_reported)
	engine.max_steps_per_frame = 4
	for frame_delta in [NAN, INF, -1.0]:
		engine._process(frame_delta)
		invalid_results.append(engine.step_count == 0 and engine._clock_error_reported)
	Engine.print_error_messages = errors_enabled
	for result in invalid_results:
		_check(result, "invalid clock input prevents automatic stepping")
	engine._process(1.0 / 60.0)
	_check(engine.step_count == 1 and not engine._clock_error_reported, "valid configuration resumes automatic stepping")
	_empty(false)
	engine.config.initial_sheep = 24
	engine.config.initial_wolves = 4
	engine.config.initial_sheepdogs = 2
	engine.reset_simulation()
	for index in range(120):
		engine._process(1.0 / 60.0)
	var expected: Array = [engine.rng.state, engine.entity_service.capture_count]
	for animal in engine.entity_service.entities:
		expected.append([animal.identity.entity_id, animal.motion.position, animal.motion.velocity, animal.brain.current_behavior])
	engine.reset_simulation()
	for index in range(60):
		engine._process(1.0 / 120.0)
		engine._process(3.0 / 120.0)
	var actual: Array = [engine.rng.state, engine.entity_service.capture_count]
	for animal in engine.entity_service.entities:
		actual.append([animal.identity.entity_id, animal.motion.position, animal.motion.velocity, animal.brain.current_behavior])
	_check(engine.step_count == 120 and expected == actual and is_zero_approx(engine._accumulator), "frame grouping preserves seeded simulation at equal step count")
	engine.reset_simulation()
	engine._process(interval * 0.4)
	var replacement: SimulationConfig = engine.config.copy_config()
	replacement.initial_sheep = 1
	engine.request_config_apply(replacement)
	engine._process(0.0)
	_check(engine._accumulator == 0.0 and engine.step_count == 0 and engine.entity_service.get_counts().x == 1, "configuration restart clears partial step")

func _verify_ecs_pool() -> void:
	_empty()
	var service: EntityService = engine.entity_service
	service.clear()
	var prey := _animal(AnimalEntity.Kind.SHEEP, Vector2(500, 300))
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(100, 300))
	var dog := _animal(AnimalEntity.Kind.SHEEPDOG, Vector2(900, 300))
	var memory := wolf.memory
	memory.target = prey
	dog.dog_state.protected_sheep = prey
	dog.dog_state.collected_sheep = prey
	var generation := prey.identity.generation
	var entity_handle := prey.id
	var motion := prey.motion
	var view := prey.brain.view
	var player := prey.brain.player
	player.get_blackboard().set_var(&"pool_test", 42)
	prey.sheep_state.has_panic = true
	prey.motion.velocity = Vector2(20, 10)
	engine.debug_service.selected = prey
	_check(service.capture(prey) and not service.capture(prey), "pooled death captures exactly once")
	_check(memory.target == null and engine.debug_service.selected == null, "death invalidates target and selection immediately")
	service.remove_expired()
	_check(not prey.enabled and view.visible and not player.active, "disabled entity keeps a short corpse presentation")
	_check(not engine.ecs_world.query.with_all([SheepState]).enabled().execute().has(prey), "enabled queries exclude corpse")
	_check(engine.ecs_world.query.with_all([SheepState]).disabled().execute().has(prey), "disabled entity remains registered")
	var remaining := prey.identity.death_remaining
	engine._process(1.0)
	_check(prey.identity.death_remaining == remaining, "pause freezes corpse lifetime")
	_step(20)
	_check(is_instance_valid(prey) and not view.visible and service.pools[0].has(prey), "corpse is hidden and pooled without freeing")
	var retained := service.all_entities.size()
	var replacement := _animal(AnimalEntity.Kind.SHEEP, Vector2(600, 400))
	_check(replacement == prey and replacement.id == entity_handle and service.all_entities.size() == retained, "spawn reuses the same GECS entity")
	_check(replacement.motion == motion and replacement.brain.view == view and replacement.brain.player == player, "reuse preserves component and scene objects")
	_check(replacement.identity.generation != generation and replacement.identity.alive and replacement.enabled, "reuse begins a new enabled life")
	_check(memory.target == null, "old target reference cannot follow a reused entity")
	_check(not replacement.sheep_state.has_panic and replacement.motion.velocity == Vector2.ZERO and replacement.memory.target == null, "reuse clears previous life state")
	_check(not player.get_blackboard().has_var(&"pool_test"), "reuse clears behavior tree blackboard")
	_check(replacement.motion.position == Vector2(600, 400) and view.global_position == replacement.motion.position, "reuse synchronizes spawn presentation")
	for index in range(3):
		engine.reset_simulation()
	_check(service.all_entities.size() == retained and service.get_counts() == Vector3i.ZERO, "empty resets reuse allocated objects without growth")

func _verify_debug_panel() -> void:
	_empty()
	engine.entity_service.clear()
	var debug: DebugService = engine.debug_service
	var panel: DebugPanel = scene.hud.debug_panel
	var wolf := _animal(AnimalEntity.Kind.WOLF, Vector2(400, 300))
	var sheep := _animal(AnimalEntity.Kind.SHEEP, Vector2(550, 300))
	wolf.memory.target = sheep
	wolf.memory.target_visible = false
	wolf.memory.last_seen_position = Vector2(500, 320)
	debug.selected = wolf
	debug.show_details = false
	debug.selected_only = true
	var event := InputEventKey.new()
	event.pressed = true
	event.keycode = KEY_F3
	scene.hud._unhandled_key_input(event)
	_check(panel.visible and not scene.hud.parameters.visible, "F3 opens DebugPanel separately from parameters")
	panel.enabled_toggle.button_pressed = true
	_check(debug.show_details, "panel enables auxiliary visuals immediately")
	panel.scope.select(1)
	panel.scope.item_selected.emit(1)
	_check(not debug.selected_only, "panel supports all-animal scope")
	var rng_state: int = engine.rng.state
	var target_position := sheep.motion.position
	var remembered := wolf.memory.last_seen_position
	wolf.wolf_state.howl_pending = true
	engine.wolf_system.resolve_interactions(wolf, 0.0)
	_check(debug.howl_events.size() == 1, "settled howl records a visual event")
	var origin: Vector2 = debug.howl_events[0]["position"]
	var radius: float = debug.howl_events[0]["radius"]
	wolf.motion.position += Vector2(40, 0)
	var draft: SimulationConfig = engine.config.copy_config()
	draft.wolf.howl_radius += 10.0
	engine.request_config_apply(draft)
	engine._process(0.0)
	_check(debug.howl_events[0]["position"] == origin and debug.howl_events[0]["radius"] == radius, "howl snapshots origin and range at settlement")
	engine._process(1.0)
	_check(debug.howl_events[0]["elapsed"] == 0.0, "pause freezes howl pulse")
	debug.advance_visuals(0.1)
	_check(is_equal_approx(debug.howl_events[0]["elapsed"], 0.1), "visual event advances with simulation delta")
	panel.controls["howl"].button_pressed = false
	_check(debug.howl_events.is_empty(), "disabling howl clears pending presentation")
	panel.controls["howl"].button_pressed = true
	_check(debug.howl_events.is_empty(), "reenabling does not replay old howls")
	_check(engine.rng.state == rng_state and sheep.motion.position == target_position and wolf.memory.last_seen_position == remembered, "visual controls preserve RNG and hidden target memory")
	panel.close()
	_check(debug.show_details and not panel.visible, "closing panel preserves visual choices")
	event.keycode = KEY_F2
	scene.hud._unhandled_key_input(event)
	_check(scene.hud.parameters.visible and not panel.visible, "F2 keeps panels mutually exclusive")
	event.keycode = KEY_F3
	scene.hud._unhandled_key_input(event)
	_check(panel.visible and not scene.hud.parameters.visible, "opening DebugPanel closes parameters")
	event.keycode = KEY_ESCAPE
	scene.hud._unhandled_key_input(event)
	_check(not panel.visible, "Escape closes DebugPanel")
	engine.reset_simulation()
	_check(debug.show_details and not debug.selected_only and debug.howl_events.is_empty(), "reset keeps visual preferences and clears effects")
	debug.show_details = false
	debug.selected_only = true

func _run() -> void:
	DirAccess.make_dir_recursive_absolute("res://output/verification")
	scene = load("res://Levels/Map/SCN_Root.tscn").instantiate()
	authored = scene.simulation_config
	root.add_child(scene)
	engine = root.get_node("g_gameplayEngine")
	engine.set_process(false)
	await process_frame
	_check(not engine.debug_service.show_details and not scene.hud.debug_panel.visible and engine.debug_service.selected_only, "default presentation keeps overlays off with selected-only scope")
	_verify_resources_and_vision()
	_verify_sheep()
	_verify_wolves()
	_verify_dogs()
	_verify_behavior_edges()
	_verify_runtime_config()
	_verify_controls()
	_verify_clock()
	_verify_ecs_pool()
	_verify_debug_panel()
	engine.stop_simulation()
	scene.queue_free()
	await process_frame
	await process_frame
	authored = null
	scene = null
	engine = null
	print("SIMULATION_VERIFICATION checks=%d failures=%d" % [checks, failures])
	quit(0 if failures == 0 else 1)
